<?php 
include '../php/config.php';
$numbering = 1;
$query = $conn->query("SELECT * FROM articles");
while ($row=$query->fetch_assoc()) {
	echo readMore($numbering++,$row['title'],$row['body'],$row['date'],$row['image'],$row['category'],$row['id']);
    

}
function readMore($numbering,$title,$body,$date,$image,$category,$id){
        return 
            "<tr>
            <td>".$numbering."</td> 
            <td>".$title."</td>
            <td class='readMore'>
               <span class='bg' id='body".$id."'>". substr($body, 0,90) ."</span>
               <span id='".$id."' style='display: none;'>".$body."</span>
               <button type='button' class='vc btn btn-primary' value='".$id."' >...read more</button>
            </td>
            <td>".$date."</td>
            <td><img src='../assets/img/articles/".$image."' width='50' height='50'></td>
            <td>".$category."</td>
            <td><button type='button' class='deletenovels btn btn-light' value='".$id."'><i class='fa fa-trash'></i></button>
            </tr>
           ";
       
    

    }



 ?>