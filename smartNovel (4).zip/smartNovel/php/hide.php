<?php 
include 'config.php';
$email = $_SESSION['email'];
$select = $conn->query("SELECT * FROM users WHERE email='$email'");
if ($select->num_rows>0) {
  while ($row=$select->fetch_assoc()) {
    echo "<script>alert('".$row['disable']."')</script>";

  }
}


 ?>