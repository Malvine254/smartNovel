<?php 
$conn = new mysqli("localhost","root","","myNovel");
if ($conn) {
	//echo "conected..";
}else{
	echo "connection error";
	exit();
}



 ?>