<?php 
include 'config.php'; 
session_start();
$email = mysqli_real_escape_string($conn,$_SESSION['email']);
$select = $conn->query("SELECT * FROM draft WHERE email = '$email' AND new='0' LIMIT 1");
	if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			$string = $row['status'];
			$array =  explode(",", $string);

			
		}
		echo json_encode($array);
	}



 ?>