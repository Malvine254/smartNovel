<?php 
if (isset($_POST['category'])) {
	require '../../php/config.php';
	$category = mysqli_real_escape_string($conn,$_POST['category']);
	$lowerCase = strtolower($category);
	$select = $conn->query("SELECT * FROM categories WHERE LOWER(category)='$lowerCase'");
	if ($select->num_rows>0) {
		echo "Category exists";
	}else{
		$insert = $conn->query("INSERT INTO categories(category) VALUES('$category')");
		if ($insert) {
			echo "Category Added";
		}else{
			echo "Server error";
		}
	}
	
}


 ?>