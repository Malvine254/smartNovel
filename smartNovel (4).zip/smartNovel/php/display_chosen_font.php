<?php 
  require 'config.php';
  session_start();
  $email = $_SESSION['email'];
  $select = $conn->query("SELECT * FROM users WHERE email='$email'");
  if ($select->num_rows>0) {
    while ($row=$select->fetch_assoc()) {
     echo $font_size = $row['font_size'];
    }
  }else{
    echo "no data";
  }










 ?>