<?php 
session_start();
if (isset($_SESSION['admin_email'])) {
	// code...
}else{
	header("location:../admin/login");
}



 ?>