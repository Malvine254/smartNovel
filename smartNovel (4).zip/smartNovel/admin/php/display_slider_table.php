<?php 
include '../php/config.php';
$numbering = 1;
$query = $conn->query("SELECT * FROM slider");
while ($row=$query->fetch_assoc()) {
	echo " <tr>
            <td>".$numbering++."</td>
            <td>".$row['title']."</td>
            <td>".$row['body']."</td>
            <td><center><img width='90' height='70' src='../".$row['image']."'></center></td>
            <td><button type='button' class='deleteslider btn btn-light' value='".$row['id']."'><i class='fa fa-trash'></i></button></td>
          </tr>


	";

}
 ?>