<?php 
session_start();
include 'config.php';
$email = mysqli_real_escape_string($conn, $_SESSION['email']);
$delete = $conn->query("DELETE FROM users WHERE email='$email'");
if ($delete) {
	unset($_SESSION['email']);
	echo "Account deleted";

}else{
	echo "failed";
}


 ?>