<?php 

require '../../php/config.php';
$select = $conn->query("SELECT * FROM articles LIMIT 1");
$index = 0;
$arrayName = "";
while ($row=$select->fetch_assoc()) {
date_default_timezone_set("Africa/Nairobi");
$time_now = time();
$time_sent = $row['time_stamp'];
$time_differnce = $time_now-$time_sent;
$sec = $time_differnce%60;
$hours = round($time_differnce/3600);
$min = round($time_differnce/60);
$day = round($hours/24);
$week = round($day/7);
$month = round($week/4);
if ($hours>1 || $month<7) {
   $array = [[$day,'Hours','indigo  '],[round($hours/3600),'Hours','red'],[$week,'Weeks','green'], [$month,'Months','blue'],[round($month/12),'Year','black']];
   print_r(json_encode( $array));

}

            
}





?>


 