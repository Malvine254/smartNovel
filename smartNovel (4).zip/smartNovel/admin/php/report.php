<?php 
$numbering = 1;
require '../php/config.php';
if (isset($_GET['type'])) {
	$selectedPart = mysqli_real_escape_string($conn,$_GET['type']);
	$select = $conn->query("SELECT * FROM articles");
	if ($select->num_rows>0) {
			while ($row=$select->fetch_assoc()) {
				date_default_timezone_set("Africa/Nairobi");
				$time_now = time();
				$time_sent = $row['time_stamp'];
				$time_differnce = $time_now-$time_sent;
				$sec = $time_differnce%60;
				$hours = round($time_differnce/3600);
				$min = round($time_differnce/60);
				$day = round($hours/24);
				$week = round($day/7);
				$month = round($week/4);
				if ($selectedPart === "Daily Report") {
				if ($sec>0 && $day<7) {
					echo display($numbering++,$row['title'],$row['author'],finalTime($sec,$min,$hours,$day,$week,$month),$row['category'],$row['id'],$row['frequent']);
				}

					
				}else if($selectedPart === "Weekly Report" && $day>=7 && $month<1){
					echo display($numbering++,$row['title'],$row['author'],finalTime($sec,$min,$hours,$day,$week,$month),$row['category'],$row['id'],$row['frequent']);
				}else if($selectedPart === "Monthly Report" && $week>3 && $month<12){
					echo display($numbering++,$row['title'],$row['author'],finalTime($sec,$min,$hours,$day,$week,$month),$row['category'],$row['id'],$row['frequent']);
				}




			}
		}else{
			echo "no data";
		}
	
	
}else{
	//echo "<script>alert('set')</script>";
	$select = $conn->query("SELECT * FROM articles");
	if ($select->num_rows>0) {
			while ($row=$select->fetch_assoc()) {
				date_default_timezone_set("Africa/Nairobi");
				$time_now = time();
				$time_sent = $row['time_stamp'];
				$time_differnce = $time_now-$time_sent;
				$sec = $time_differnce%60;
				$hours = round($time_differnce/3600);
				$min = round($time_differnce/60);
				$day = round($hours/24);
				$week = round($day/7);
				$month = round($week/4);
				echo display($numbering++,$row['title'],$row['author'],finalTime($sec,$min,$hours,$day,$week,$month),$row['category'],$row['id'],$row['frequent']);
				
			}
		}
}
function frequency($frequency){
	if ($frequency == NULL) {
		return 0;
	}else{
		return count(explode(',', $frequency));
	}
	
	

}
function display($numbering,$title,$author,$date,$category,$id,$frequency){
	return "
	<tr>
		<td>".$numbering."</td>
		<td>".$title."</td>
		<td>".$author."</td>
		<td>".$date."</td>
		<td>".frequency($frequency)."</td>
		<td>".$category."</td>
		<td><button class='fa fa-trash hide2 btn btn-light deletereports'></button></td>
	</tr>
	";
}
function finalTime ($sec,$min,$hour,$day,$week,$month){
	if ($min<59) {
		if ($min==1) {
			return $min." min ago";
		}else{
			return $min." mins ago";
		}

	}else if($hour<24 ){
		if ($hour==1) {
			return $hour." hour ago";
		}else{
			return $hour." hours ago";
		}

	}else if($day<7){
		if ($day==1) {
			return $day." day ago";
		}else{
			return $day." days ago";
		}

	}else if($week<4 ){
		if ($week==1) {
			return $week." week ago";
		}else{
			return $week." weeks ago";
		}


	}else if($month<12 ){
		if ($month==1) {
			return $month." month ago";
		}else{
			return $month." months ago";
		}


	}if ($sec<59) {
		if ($sec==1) {
			return $sec." Just now";
		}else{
			return $sec." secs ago";
		}

	}
}

 ?>


 