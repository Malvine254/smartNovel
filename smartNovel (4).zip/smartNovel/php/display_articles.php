<?php
require 'config.php';
if (isset($_GET['id'])) {
   $id =  strtolower(mysqli_real_escape_string($conn,$_GET['id']));
   $select = $conn->query("SELECT * FROM articles WHERE LOWER(category) LIKE '%$id%'");
    if ($select->num_rows>0) {
      while ($row=$select->fetch_assoc()) {
        echo limitWords($row['body'],$row['id'],$row['image'],$row['category'],$row['date'],$row['title'],$row['body'],$row['author'],$row['profile']);
      }
    }else{
      echo "no data";
    }
 }else{ 
$select = $conn->query("SELECT * FROM articles LIMIT 2");
if ($select->num_rows>0) {
	while ($row=$select->fetch_assoc()) {
    echo limitWords($row['body'],$row['id'],$row['image'],$row['category'],$row['date'],$row['title'],$row['body'],$row['author'],$row['profile']);
	}
}else{
	echo "no data";
}
}



function limitWords($length,$id,$image,$category,$date,$title,$body,$author,$profile){
  if (strlen($length)>700) {
    return "<div class='d-md-flex post-entry-2 half'>
              <a href='single-post.php?id=".$id."' class='me-4 thumbnail'>
                <img style='height:600px; width:600px;' src='".$image."' alt='' class='img-fluid'>
              </a>
              <div>
                <div class='post-meta'><span class='date'>".$category."</span> <span class='mx-1'>&bullet;</span> <span>".$date."</span></div>
                <h3><a href='single-post.php?id=".$id."'>".$title."</a></h3>
                <p>".boldFirstLetter(substr($body, 0,700))."<a class='text-danger' href=''> read more...</a></p>
                <div class='d-flex align-items-center author'>
                  <div class='photo'><img  src='assets/img/profile/".$profile."' alt='' class='img-fluid'></div>
                  <div class='name'>
                    <h3 class='m-0 p-0'>".$author."</h3>
                  </div>
                </div>
              </div>
            </div>";
  }else{
    return "<div class='d-md-flex post-entry-2 half'>
              <a href='single-post.php?id=".$id."' class='me-4 thumbnail'>
                <img style='height:400px;' src='".$image."' alt='' class='img-fluid'>
              </a>
              <div>
                <div class='post-meta'><span class='date'>".$category."</span> <span class='mx-1'>&bullet;</span> <span>".$date."</span></div>
                <h3><a href='single-post.php?id=".$id."'>".$title."</a></h3>
                <p>".boldFirstLetter($body)."<a class='text-danger'></p>
                <div class='d-flex align-items-center author'>
                  <div class='photo'><img height='200' width='100' src='assets/img/profile/".$profile."' alt='' class='img-fluid'></div>
                  <div class='name'>
                    <h3 class='m-0 p-0'>".$author."</h3>
                  </div>
                </div>
              </div>
            </div>";
  }

}

function boldFirstLetter($string){
  $new_string = "";
  $final = strlen($string);
  for ($i=0; $i < $final; ++$i) { 
    if ($i<1) {
      $new_string .='<span class="h1">'.$string[$i].'</span>';
    }else{
      $new_string .= $string[$i];
    }
  }
  return $new_string;

}




 ?>