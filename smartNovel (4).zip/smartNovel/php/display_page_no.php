<?php 
  require 'config.php';
  $select = $conn->query("SELECT * FROM articles ");
  $page_number = $select->num_rows/2;
  $numbering = 1;
    echo "Page <a href=\"#\" class=\"active\">1</a> of <a href=\"#\" class=\"active\">".$page_number."</a> ";

 
function firstPage(){

}




 ?>