<?php 
	include "config.php";
	$lname = mysqli_real_escape_string($conn,$_POST['lname']);
	$fname = mysqli_real_escape_string($conn,$_POST['fname']);
	$email = mysqli_real_escape_string($conn,$_POST['email']);
	$disability = mysqli_real_escape_string($conn,$_POST['disability']);
	$password = mysqli_real_escape_string($conn,$_POST['password']);
	$confirmPassword = mysqli_real_escape_string($conn,$_POST['confirmPassword']);
	$encPassword = md5($password);
	$checkEmail = $conn->query("SELECT  * FROM users WHERE email='$email'");
	if ($checkEmail->num_rows>0) {
		echo "Email Address already taken";
	}else{
			if ($confirmPassword==$password) {
			$id = rand(500,50000);
			$result = $conn->query("INSERT INTO users (fname,lname,email,disability,password) VALUES ('$fname','$lname','$email','$disability','$encPassword')");
				if ($result) {
					echo "Registration Successful";
				}else{
					echo "Failed to Sent Message";
				}

			}else{
				echo "Passwords do Not Match!!";
				
			}

		
		
		}
		

		
	

	


 ?>