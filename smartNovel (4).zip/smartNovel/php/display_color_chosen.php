<?php 
  require 'config.php';
  session_start();
  $email = $_SESSION['email'];
  $select = $conn->query("SELECT * FROM users WHERE email='$email'");
  if ($select->num_rows>0) {
    while ($row=$select->fetch_assoc()) {
     echo $text_color = $row['text_color'];
    }
  }else{
    echo "no data";
  }










 ?>