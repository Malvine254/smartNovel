<?php 
include '../php/config.php';
$numbering = 1;
$email = mysqli_real_escape_string($conn,$_SESSION['admin_email']);
$query = $conn->query("SELECT * FROM admin WHERE email='$email'");
while ($row=$query->fetch_assoc()) {
	echo " 
        <img width=\"40\" height=\"40\" style=\"border-radius: 50%;\" src=\"../assets/img/profile/".$row['profile']."\">

	";



}
 ?>