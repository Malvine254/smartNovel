<?php 
if (isset($_GET['id'])) {
  require 'config.php';
  $numbering = 1;
  $id = mysqli_real_escape_string($conn,$_GET['id']);
  $email = $_SESSION['email'];
  //$new_email = $email.',';
  $select = $conn->query("SELECT * FROM articles WHERE id_auto='$id'");
  if ($select->num_rows>0) {
    while ($row=$select->fetch_assoc()) {
      // $length = array(500,500,500,500,500);
      // $offset = 0;
      // $str = $row['body'];
      // $result = implode("-", array_map(function($length) use ($str,&$offset) {
      //     $part = substr($str, $offset, $length);
      //     $offset +=$length;
      //     return $part."<br></br>";
      // },$length));
      //echo $result;

        if ($row['frequent']===NULL) {
        $conn->query("UPDATE articles SET frequent='$email' WHERE id_auto='$id'");
      }else{
        $array = explode(',', $row['frequent']);
        if (in_array($email, $array)) {
          // echo "exists";
        }else{
           $new_Update = $row['frequent'].",".$email;
            $conn->query("UPDATE articles SET frequent='$new_Update' WHERE id_auto='$id'");
        }
        
        }
             echo " 
              <div class='row'>".hide()."</div>
               </div><div class='d-md-flex post-entry-2 half shadow'>
               <div>
               
                <div>
                <div class='row'>
                  <center>
                  <div class='col-6 mt-4'>
                  <div class='' id=\"google_translate_element\"></div
                </div>
                  <div class='col-6 col mt-4 form-group'>
                  <select id='cmd' class=' form-control'>
                    <option selected disabled>Download Novel as: </option>
                    <option value='1'>PDF</option>
                    <option value='2'>MP3</option>
                  </select>

                </div>
                </center>
                </div>
                </div>
                  <div id='content2' style=' margin-left: 120px; margin-right: 120px;-webkit-print-color-adjust: exact !important
                    color-adjust: exact !important;
                    print-color-adjust: exact !important;'>
                  <center>
                  <div style='background-image: url(assets/img/articles/".$row['image'].");background-repeat: no-repeat; height: 500px;background-size: 100%; background-position:center;margin-top:30px; text-transform:uppercase;'><br><br><br>
                  <div class='post-meta'><h6 class='text-light'><span class='date'>".$row['category']."</span> <span class='mx-1 '>&bullet;</span> <span>".$row['date']."</span></h6></div>
                    <h1 class='readText mt-10 text-light text-center'><u>".$row['title']."</u></h1>
                    <div><img style='border-radius:50%;' width='50' height='50'  src='assets/img/profile/".$row['profile']."' > <h3 class='m-0 p-0 text-light'>".$row['author']."</h3></div>
                    </div>
                    </center>
                   <div class='readText'>".$row['body']."</div>
                  <div class='d-flex align-items-center author'>
                  <div class='name'>
                  </div>
                  </div>
                </div>
              </div></div>
               

            ";
    }
  }else{
    echo "no data";
  }
  
  }
function hide(){
  include 'config.php';
$email = $_SESSION['email'];
$select = $conn->query("SELECT * FROM users WHERE email='$email'");
if ($select->num_rows>0) {
  while ($row=$select->fetch_assoc()) {
  if ($row['disable']==0) {
   return "";
  }else{
    return " <div class='justify-content-center mb-3'>
                        <center>
                          <button type='button' id='playButton'' class='col fa fa-play btn btn-info text-light'> START ASSISTANCE</button>
                          <button type='button' id='stopButton' class='col fa fa-stop btn btn-danger' > RESUME ASSISTANCE</button>
                          <button type='button' id='pauseButton' class=' col fa fa-pause btn btn-primary'> PAUSE ASSISTANCE</button>
                          <span id='status'></span>
                        </center>
                      </div>";
      
  }

  }
}
}







 ?>