# Multi Language

> Multi Language Jquery Plugin

## How to use:

```
getLanguage() // choose language by localStorage or default in jQuery config  
```
```
setLanguage('en') // change language immediately
```

## Demo:
[Demo]



[demo]:https://makbarpour.ir/github/demo/multi-language/

## Special Thanks:
- @mingchoi
