<?php 

require 'config.php';
$select = $conn->query("SELECT * FROM categories");
if ($select->num_rows>0) {
	while ($row=$select->fetch_assoc()) {
		echo "<li><a href=\"category?id=".$row['category']."\">".$row['category']."</a></li>";
	}
}else{
	echo "<li><a >No category was found!!</a></li>";
}


 ?>