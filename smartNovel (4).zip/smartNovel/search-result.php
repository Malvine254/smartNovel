<?php require 'php/check_session.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>ZenBlog Bootstrap Template - Search Results</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="modal1/modal.css">

  <!-- Template Main CSS Files -->
  <link href="assets/css/variables.css" rel="stylesheet">
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: ZenBlog - v1.3.0
  * Template URL: https://bootstrapmade.com/zenblog-bootstrap-blog-template/
  * Author: BootstrapMade.com
  * License: https:///bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <div id="loading">
    <img width="45px" height="45px" id="loader-image" src="loader/loader.gif">
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1>SmartNovel</h1>
      </a>

     <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index">HOME</a></li>
          <li class="dropdown"><a href="category"><span>CATEGORIES</span><i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
             <?php include 'php/display_category.php'; ?>
            </ul>
          </li>
          <li><a href="create">CREATE NOVEL</a></li>
          <li><a href="settings">SETTINGS</a></li>
           <li><a id="logOut">LOGOUT</a></li>
        </ul>
      </nav><!-- .navbar -->

      <div class="position-relative">
        <a href="#" class="mx-2"><span class="bi-facebook"></span></a>
        <a href="#" class="mx-2"><span class="bi-twitter"></span></a>
        <a href="#" class="mx-2"><span class="bi-instagram"></span></a>

        <a  href="#" class="mx-2 js-search-open"  id="searchButton"><span  class="bi-search"></span></a>
        <i  class="bi bi-list mobile-nav-toggle"></i>

        <!-- ======= Search Form ======= -->
        <div class="search-form-wrap js-search-form-wrap">
          <form action="search-result.html" class="search-form">
            <span class="icon bi-search"></span>
            <h1 id="textToSearch" style="display: none;">Please, enter text to search.</h1>
            <input id="searchMe" type="text" placeholder="Search" class="form-control">
            <button  class="btn js-search-close"><span class="bi-x"></span></button>
          </form>
        </div><!-- End Search Form -->

      </div>

    </div>

  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Search Results ======= -->
    <section id="search-result" class="search-result">
      <div class="container">
        <div class="row">
          <div class="col-md-10">
            <h3 class="category-title">Search Results</h3>

            

            
           <?php include 'php/search.php'; ?>

            <!-- Paging -->
            <!-- <div class="text-start py-4">
              <div class="custom-pagination">
                <a href="#" class="prev">Prevous</a>
                <a href="#" class="active">1</a>
                <a href="#">2</a>
                <a href="#">3</a>
                <a href="#">4</a>
                <a href="#">5</a>
                <a href="#" class="next">Next</a>
              </div>
            </div> --><!-- End Paging -->

          </div>
        </div>
      </div>
    </section> <!-- End Search Result -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
 <!-- Trigger/Open The Modal -->
<!-- <button id="myBtn">Open Modal</button> -->

<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <div id="modelContent">
     
    </div>
  </div>

</div>


  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="assets/jquery/jquery.min.js"></script>
  <script src="assets/js/articulate.js"></script>
  <script src="assets/js/settings1.js"></script>
  <script type="text/javascript" src="modal/modal.js"></script>

  <script type="text/javascript">
    $(document).ready(()=>{
       if (window.loaded=true) {
         $("#loading").css("display","none");
      }
    })
    $("#textToSearch").articulate("stop")
    //$("#searchTitle").articulate("speak")
    articulateRate($(".searchTitle"))
    disableVoice($(".searchTitle"))
    

     $(document).keypress(function(e){

            var key = (event.keyCode ? event.keyCode : event.which);
            var ch = String.fromCharCode(key)
             var search =  $("#searchMe").val()
           if (ch==='5') {
            //console.log(ch)
            $("#searchButton")[0].click("click")
            $(".searchTitle").articulate('stop')
            articulateRate($("#textToSearch"))
            disableVoice($("#textToSearch"))
            setTimeout(function(){
              $("#searchMe").focus()

            },100)
            
            //$("#searchMe").focus()id="searchButton"
           }else if(ch==='3'){
            setInterval(()=>{
               //alert("success")
                  window.location.assign("search-result.php?search="+search)
                  $("#searchMe").blur()
            
              
            },2000)

           }else if(ch==='7'){
            var ids = $(".getId").text()
            // $(".clickedLink").click(function(){

              console.log(ids+"<br>")
            
           }

          })
      // change color
     changeColor($('body'))
     // change font
     changeFontSize($('body'))

  </script>

</body>

</html>