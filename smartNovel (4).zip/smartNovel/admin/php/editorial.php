<?php 
require '../php/config.php'; 
if (isset($_GET['i'])) {
	$id = mysqli_real_escape_string($conn,$_GET['i']);
	$check = $conn->query("SELECT * FROM draft WHERE id='$id'");
	if ($check->num_rows>0) {
		while ($row=$check->fetch_assoc()) {
			echo "<h2 style='display:none;' id='finalEmail' class='text-center'>".$row['email']."</h2>
			<h2 style='display:none;' id='finalImage' class='text-center'>".$row['image']."</h2>
			<h2 style='display:none;' id='finalDate' class='text-center'>".$row['date']."</h2>
			<div  id=''><div rows='7' class='row mb-6 shadow' >
	      <!-- <h5 class='mb-0 '>Add Title</h5> -->
	      <h2 class='text-center'>Heading: <b contenteditable id='finalTitle'>".$row['title']."</b></h2>
	      
	      <h2  class=''>Category: <b contenteditable id='finalCategory'>".$row['category']."</b></h2>
	      
	    <center><textarea contenteditable id='editor'>".$row['body']."</textarea></center>
	      
	    </div></div>  <script type='text/javascript'> 
	        CKEDITOR.replace( 'editor', { 
	                width:['90%']

	            }); </script> <center><button id='finishPub' type='button' class='btn btn-primary mt-3'>Confirm Publishing New Novel</button></center>";
		}
	}else{
			echo "<center>No novel selected for editing</center>";
		}
	}






 ?>