<?php  
if (isset($_POST['id'])) {
	include '../../php/config.php';
	$id = $_POST['id'];
	$del = $conn->query("DELETE FROM categories WHERE id='$id'");
	if ($del) {
		echo "Deleted";
	}else{
		echo "failed";
	}
}



 ?>