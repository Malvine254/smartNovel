<?php 
include '../php/config.php';
$numbering = 1;
$query = $conn->query("SELECT * FROM admin");
while ($row=$query->fetch_assoc()) {
	echo " <tr>
            <td>".$numbering++."</td>
            <td>".$row['name']."</td>
            <td>".$row['email']."</td>
            <td>".$row['phone']."</td>
            <td><button type='button' class='deleteadmins btn btn-light' value='".$row['id']."'><i class='fa fa-trash'></i></button></td>
          </tr>


	";

}
 ?>