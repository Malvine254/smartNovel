<?php 
  require 'config.php';
  $select = $conn->query("SELECT * FROM articles LIMIT 1");
  if ($select->num_rows>0) {
    while ($row=$select->fetch_assoc()) {
      $frequency = count(explode(',', $row['frequent']));
     if ($frequency>=2) {
       
         echo " <div class='post-entry-1'>
                  <a href='single-post?id=".$row['id_auto']."'><img src='assets/img/articles/".$row['image']."' alt=' ' class='img-fluid'></a>
                  <div class='post-meta'><span class='date'>".$row['category']."</span> <span class='mx-1'>&bullet;</span> <span>".$row['date']."</span></div>
                  <h2><a href='single-post?id=".$row['id']."'>".$row['title']."</a></h2>
                </div>";
     }
      
    }

     
  }else{
    echo "no data";
  }










 ?>