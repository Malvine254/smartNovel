<?php 
require '../../php/config.php';
$fullName = mysqli_real_escape_string($conn,$_POST['fullName']);
$email = mysqli_real_escape_string($conn,$_POST['email']);
$phone = mysqli_real_escape_string($conn,$_POST['phone']);
$password = mysqli_real_escape_string($conn,$_POST['password']);
$check = $conn->query("SELECT * FROM admin WHERE email='$email'");
if ($check->num_rows>0) {
	echo "Email taken";
}else{
	$insert = $conn->query("INSERT INTO admin(name,email,phone,password) VALUES('$fullName','$email','$phone','$password')");
	if ($insert) {
		echo "admin added";
	}else{
		echo "failed";
	}
}




 ?>