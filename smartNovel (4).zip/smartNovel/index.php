<?php require 'php/check_session.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Home</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS Files -->
  <link href="assets/css/variables.css" rel="stylesheet">
  <link href="assets/css/main.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="fontAwesome/all.min.css">
  <link rel="stylesheet" type="text/css" href="fontAwesome/fontawesome.min.css">
  <link rel="stylesheet" type="text/css" href="modal/modal1.css">
  

  <!-- =======================================================
  * Template Name: ZenBlog - v1.3.0
  * Template URL: https://bootstrapmade.com/zenblog-bootstrap-blog-template/
  * Author: BootstrapMade.com
  * License: https:///bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <div id="loading">
    <img width="45px" height="45px" id="loader-image" src="loader/loader.gif">
  </div>
  
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1>SmartNovel</h1>
      </a>

       <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index"><u>HOME</u></a></li>
          <li class="dropdown"><a href="category"><span>CATEGORIES</span><i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
             <?php include 'php/display_category.php'; ?>
            </ul>
          </li>
          <li><a href="create">CREATE NOVEL</a></li>
          <li><a href="settings">SETTINGS</a></li>
           <li><a id="logOut">LOGOUT</a></li>
        </ul>
      </nav><!-- .navbar -->

      <div class="position-relative">
        <a href="#" class="mx-2"><span class="bi-facebook"></span></a>
        <a href="#" class="mx-2"><span class="bi-twitter"></span></a>
        <a href="#" class="mx-2"><span class="bi-instagram"></span></a>

        <a  href="#" class="mx-2 js-search-open"  id="searchButton"><span  class="bi-search"></span></a>
        <i  class="bi bi-list mobile-nav-toggle"></i>

        <!-- ======= Search Form ======= -->
        <div class="search-form-wrap js-search-form-wrap">
          <form action="search-result.html" class="search-form">
            <span class="icon bi-search"></span>
            <h1 id="textToSearch" style="display: none;">Please, enter text to search.</h1>
            <input id="searchMe" type="text" placeholder="Search" class="form-control">
            <button  class="btn js-search-close"><span class="bi-x"></span></button>
          </form>
        </div><!-- End Search Form -->

      </div>

    </div>

  </header><!-- End Header -->

  <main id="main">

    <!-- ======= Hero Slider Section ======= -->
    <section id="hero-slider" class="hero-slider">
      <div class="container-md" data-aos="fade-in">
        <div class="row">
          <div class="col-12">
            <div class="swiper sliderFeaturedPosts">
              <div class="swiper-wrapper">
                <?php include 'admin/php/display_slider.php'; ?>
                  
                </div>
              <div class="custom-swiper-button-next">
                <span class="bi-chevron-right"></span>
              </div>
              <div class="custom-swiper-button-prev">
                <span class="bi-chevron-left"></span>
              </div>

              <div class="swiper-pagination"></div>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End Hero Slider Section -->

    <!-- ======= Post Grid Section ======= -->
    <section id="posts" class="posts">
      <div class="container" data-aos="fade-up">
        <div class="row g-5">
          <div class="col-lg-4">
           <?php 
              require 'php/config.php';
              $select = $conn->query("SELECT * FROM articles ORDER BY id DESC LIMIT 1");
              if ($select->num_rows>0) {
                while ($row=$select->fetch_assoc()) {
                  
                     echo "<div class='post-entry-1 lg'>
                          <a href='single-post?id=".$row['id_auto']."'><img style='height:400px; width: 500px;' src='assets/img/articles/".$row['image']."'  class='img-fluid'></a>
                          <div class='post-meta'><span class='date'>".$row['category']."</span> <span class='mx-1'>&bullet;</span> <span>".$row['date']."</span></div>
                          <h5><a href='single-post?id=".$row['id_auto']."'>".$row['title']."</a></h5>
                          <p class='mb-4 d-block'> " .substr($row['body'], 0,100)."...</p>

                          <div class='d-flex align-items-center author'>
                            <div class='photo'><img style='border-radius: 50%; width: 50px; height: 50px;' src='assets/img/profile/".$row['profile']."' class='img-fluid'></div>
                            <div class='name'>
                              <h3 class='m-0 p-0'>".$row['author']."</h3>
                            </div>
                          </div>
                        </div>";
              
                  }
                 
              }else{
                echo "no data";
              }

               ?>

          </div>

          <div class="col-lg-8">
            <div class="row g-5">
              <div class="col-lg-8 border-start custom-border ">
               <div id="recents"></div>
               
                
              </div>

              <!-- Trending Section -->
              <div class="col-lg-4 ">

                <div class="trending">
                  <h3>Trending</h3>
                  <ul class="trending-post">
                    <div id="trendingPost"></div>
                   
                  </ul>
                </div>

              </div> <!-- End Trending Section -->
            </div>
          </div>

        </div> <!-- End .row -->
      </div>
    </section> <!-- End Post Grid Section -->
  </main><!-- End #main -->

  <div id="instructions" style="display: none;">
    <h1>Welcome, <?php if (isset($_SESSION['email'])){
      include 'php/config.php';
      $email = $_SESSION['email'];
      $sql = $conn->query("SELECT * FROM users WHERE email = '$email'");
     if ($sql->num_rows>0){
     while ($row=$sql->fetch_assoc()) {
       echo $row['fname'];
     }
   }
  } 
  ?> to Smart Novel. I will be your assistant in reading and creating novels.</h1>
    <p>Step 1, Press 5, to initiate search. To complete searching, press 3. These keys apply accross all pages. </p>
  </div>
<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <div id="modelContent">
     
    </div>
  </div>

</div>

   

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="assets/jquery/jquery.min.js"></script>
  <script src="assets/js/articulate.js"></script>
  <script src="assets/js/settings1.js"></script>
  <script type="text/javascript" src="modal/modal.js"></script>
  <script>
    $(document).ready(()=>{
      if (window.loaded=true) {
         $("#loading").css("display","none");
      }
   
    

    setInterval(function(){
      $.ajax({
      url: 'php/display_recent.php',
      type: 'post',
      success: function(data){
        $("#recents").html(data)
      }
    })
    },1000)
    setInterval(function(){
      $.ajax({
      url: 'php/display_trending.php',
      type: 'post',
      success: function(data){
        $("#trendingPost").html(data)
      }
    })
    },1000)


    $(document).keypress(function(e){

        var key = (event.keyCode ? event.keyCode : event.which);
        var ch = String.fromCharCode(key)
         var search =  $("#searchMe").val()
       if (ch==='5') {
        //console.log(ch)
        $("#searchButton")[0].click("click")
        articulateRate($("#textToSearch"))
        disableVoice($("#textToSearch"))
        setTimeout(function(){
          $("#searchMe").focus()

        },100)
        
        //$("#searchMe").focus()id="searchButton"
       }else if(ch==='3'){
        setInterval(()=>{
           //alert("success")
              window.location.assign("search-result?search="+search)
              $("#searchMe").blur()
        
          
        },2000)

       }else if(ch==='6'){
      
          window.location.assign("create")
          

       }

      })
     // change color
     changeColor($('body'))
     // change font
     changeFontSize($('body'))

     $(document).ready(function(){
       //instructions to keep
        articulateRate($("#instructions"))
        disableVoice($("#instructions"))
     })
     })
  </script>

</body>

</html>