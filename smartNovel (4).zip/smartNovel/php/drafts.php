<?php
session_start();
require 'config.php';
if ( isset($_POST['title'])  && isset($_POST['body'])  && isset($_POST['category']) && isset($_POST['fileWithValue'])) {
  session_start();
  date_default_timezone_set("Africa/Nairobi");
  $title  = mysqli_real_escape_string($conn,$_POST['title']);
  $body = mysqli_real_escape_string($conn,$_POST['body']);
  $date = date('d-m-y h:i:sa');
  $category = mysqli_real_escape_string($conn,$_POST['category']);
  $email = mysqli_real_escape_string($conn,$_SESSION['email']);
  $image = mysqli_real_escape_string($conn,$_FILES['image']['name']);
 
     $select = $conn->query("SELECT * FROM users  WHERE email='$email'");
      if ($select->num_rows>0) {


        while ($row=$select->fetch_assoc()) {
           $target = "../assets/img/articles/".$image;
           $new_name = $image;
           $profile = $row['profile'];

          if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            $selectDraft = $conn->query("SELECT * FROM draft  WHERE email='$email' AND new ='0'");
            while ($row2 =$selectDraft->fetch_assoc()) {
              $db_body = $row2['body'];
              $db_title = $row2['title'];
              $db_category = $row2['category'];
              $db_image = $row2['image'];
              $db_date = $row2['date'];
              echo "<div class='d-md-flex post-entry-2 half'>
                <div>
                
                 <center> 
                 <div style='background-image: url(assets/img/articles/".$db_image.");background-repeat: no-repeat; height: 400px;background-size: 80%; background-position:center;margin-top:30px; text-transform:uppercase;'><br><br><br>
                  <div class='post-meta'><span class='date'>".$db_category."</span> <span class='mx-1'>&bullet;</span> <span>".$db_date."</span></div>
                    <h1 class='mt-10'><u>".$db_title."</u></h1>
                    <div ><img style='border-radius:50%;' width='50' height='50'  src='assets/img/profile/".$row['profile']."' > <h3 class='m-0 p-0'>".$row['fname']." ".$row['lname']."</h3></div>
                </div>
                 </center>
                
                  <p style ='margin-left: 100px; margin-right: 100px; font-size: 24px;'>".$db_body."</p>
                  <div class='d-flex align-items-center author'>
                    
                    <div class='name'>
                     
                    </div>
                  </div>
                </div>
              </div>";
            }
             
          }

          
        }
      }
       $insert = $conn->query("INSERT INTO draft (title,body,`date`,category,email,image,new) VALUES('$title','$body','$date','$category','$email','$new_name','0') ");
            if ($insert) {
              //echo "inserted";
            }
      // $select2 = $conn->query("SELECT * FROM draft  WHERE email='$email'");
      // if ($select2->num_rows>0) {
      //    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
      //      $updtae = $conn->query("UPDATE draft SET title='$title',body='$body', `date`='$date',category='$category',email='$email', image='$new_name' WHERE email='$email'");
      //    }
       
      // }else{
           
      // }
 
      
  }else{
    //session_start();
    $email = $_SESSION['email'];
    $selectDraft = $conn->query("SELECT * FROM draft  WHERE email='$email' AND new ='0' ORDER BY id DESC LIMIT 1");
            while ($row2 =$selectDraft->fetch_assoc()) {
              $db_body = $row2['body'];
              $db_title = $row2['title'];
              $db_category = $row2['category'];
              $db_image = $row2['image'];
              $db_date = $row2['date'];
              $select = $conn->query("SELECT * FROM users WHERE email='$email' ");
                while ($row=$select->fetch_assoc()) {

                
              echo "<div class='d-md-flex post-entry-2 half'>
                
                <div>
                
                 <center> 
                 <div style='background-image: url(assets/img/articles/".$db_image.");background-repeat: no-repeat; height: 400px;background-size: 80%; background-position:center;margin-top:30px; text-transform:uppercase;'><br><br><br>
                  <div class='post-meta'><span class='date'>".$db_category."</span> <span class='mx-1'>&bullet;</span> <span>".$db_date."</span></div>
                    <h1 class='mt-10 '><u>".$db_title."</u></h1>
                    <div ><img style='border-radius:50%;' width='50' height='50'  src='assets/img/profile/".$row['profile']."' > <h3 class='m-0 p-0'>".$row['fname']." ".$row['lname']."</h3></div>
                </div>
                 </center>
                
                  <p style ='margin-left: 100px; margin-right: 100px; font-size: 24px;'>".$db_body."</p>
                  <div class='d-flex align-items-center author'>
                    
                    <div class='name'>
                     
                    </div>
                  </div>
                </div>
              </div>";
            }
          }

  }

  





 ?>