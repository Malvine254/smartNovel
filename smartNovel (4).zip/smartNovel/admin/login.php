<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Login</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="../login/fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">

		<!-- STYLE CSS --> 
		<link rel="stylesheet" href="../login/css/style.css">
	</head>

	<body>

		<div class="wrapper" style="background-image: url('../login/images/back.jpg');">
			<div class="inner">
				<div class="image-holder">
					<img src="../login/images/bg-registration-form-2.jpg" alt="">
				</div>
				<?php include 'php/login.php'; ?>
				<form method="POST" action="">
					<h3>Admin Login</h3>
					<div class="form-wrapper">
						<input id="email" name="email" type="text" placeholder="Email Address" class="form-control">
						<i class="zmdi zmdi-account"></i>
					</div>
					
					<div class="form-wrapper">
						<input id="password" name="password" type="password" placeholder="Password" class="form-control">
						<i class="zmdi zmdi-lock"></i>
					</div>
					<button id="login_btn" name="login_btn">Login
						<i class="zmdi zmdi-arrow-right"></i>
					</button><br>
					<center><a href="register.php" class="text-danger" href="">Not having account?Register</a></center>
				</form>
			</div>
		</div>
		<p id="regInstructions" style="display: none;">Hello, Welcome to Smart Novel, the following are instructions to aid you in your Log in process:
		Note: Making entries will take 30 seconds each so concentration is paramount.	
		Finally, Press 5, to disable voice assistance.</p>
		<p id="failed" style="display: none;"> Incorrect Credentials. Press 1 to try again.</p>
		<p id="inputs" style="display: none;"> Input fields cannot be empty.</p>
		<script src="../assets/jquery/jquery.min.js"></script>
		 <script src="../assets/js/articulate.js"></script>

<script type="text/javascript">

</script>
		
	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>