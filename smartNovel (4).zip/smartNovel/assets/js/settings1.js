function changeColor(color){
  $.ajax({
      url: 'php/display_color_chosen.php',
      type: 'post',
      success: function(data){
        return color.attr('style','color:'+data+ "!important")
      }
    })
}

function changeFontSize(font){
  $.ajax({
      url: 'php/display_chosen_font.php',
      type: 'post',
      success: function(data){
        return font.css({"font-size":data+"px"})
        //return font.attr('style','font-size:'+data+"px !important")
        
        //$("#displayStories").html(data)
      }
    })
}

function disableVoice(object){
  $.ajax({
      url: 'php/display_voice_disable.php',
      type: 'post',
      success: function(data){
        if (data==1) {
          return object.articulate('speak')
        }else{
          return object.articulate('stop')
        }
        
      }
    })
}
function articulateRate(object){
  $.ajax({
      url: 'php/display_articulate_rate.php',
      type: 'post',
      success: function(data){
        object.articulate('rate',data)
        
      }
    })
}

$("#logOut").click(()=>{
  var retVal = confirm("Are you sure you Want to log out?")
      if (retVal==true) {
       $.ajax({
        url:"php/logout.php",
        type:"post",
        success: function(data){
          window.location.assign("login/index")

        }
       })
        return true
      }else{
        //document.write("User do not want to logout")
        return false
      }
})