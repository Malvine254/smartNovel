<?php 
if (isset($_POST['login_btn'])) {
	session_start();
	include "../php/config.php";
	$email = mysqli_real_escape_string($conn,$_POST['email']);
	$password = mysqli_real_escape_string($conn,$_POST['password']);
	$encPassword = md5($password);
	$checkEmail = $conn->query("SELECT  * FROM admin WHERE email='$email' AND password='$encPassword'");
	
	if ($checkEmail->num_rows>0) {
		
		$_SESSION['admin_email']=$email;
		header("location:index");
		
	}else{
		echo "<script>alert('Incorrect Credentials!!')</script>";
		}

}
	

	


 ?>