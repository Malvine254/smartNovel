<?php 
require '../../php/config.php';
session_start();
$title = mysqli_real_escape_string($conn,$_POST['title']);
$image = mysqli_real_escape_string($conn,$_FILES['image']['name']);
$body = mysqli_real_escape_string($conn,$_POST['body']);
$target = "../../assets/img/slider/".basename($image);
$path =  "assets/img/slider/".basename($image);
$email = $_SESSION['admin_email'];
if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
$insert = $conn->query("INSERT INTO slider (title,body,image) VALUES('$title','$body','$path')");
if ($insert) {
	echo "Slider added";
}else{
	echo "failed";
}
}else{
echo "failed to move";
}


	



 ?>