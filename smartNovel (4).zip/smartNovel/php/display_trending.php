<?php 
  require 'config.php';
  $numbering = 1;
  $select = $conn->query("SELECT * FROM articles LIMIT 6");
  if ($select->num_rows>0) {
    while ($row=$select->fetch_assoc()) {
      if ($row['frequent']!=NULL) {
         echo "  <li>
                      <a href=\"single-post?id=".$row['id_auto']."\">
                        <span class=\"number\">".$numbering++."</span>
                        <h3>".$row['title']."</h3>
                        <span class=\"author\">".$row['author']."</span>
                      </a>
                    </li>";
      }
     
    }
  }else{
    echo "no data";
  }










 ?>