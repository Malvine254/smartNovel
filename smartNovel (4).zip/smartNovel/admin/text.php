<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<script src="../ckeditor3/ckeditor.js"></script>
</head>
<body>
	<textarea id="editor"> 
		My text
		
	</textarea>
	<div id="p"></div>
	<button id="button">Click Me</button>
	 <script type='text/javascript'> 
	        CKEDITOR.replace( 'editor', {
	                width:['90%']

	            });
	        document.getElementById('button').onclick = function(){
	        	alert(document.getElementById('p').innerHTML = CKEDITOR.instances.editor.getSnapshot())
	        	//alert(document.getElementById('p').innerHTML = CKEDITOR.instances.editor.getBody().getText())
	        }
	        
	      </script>

</body>
</html>