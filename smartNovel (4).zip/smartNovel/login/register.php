<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Registration</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">

		<!-- STYLE CSS --> 
		<link rel="stylesheet" href="css/style.css">
	</head>

	<body>

		<div class="wrapper mt-5" style="background-image: url('images/back.jpg');">
			<div class="inner">
				<div class="image-holder">
					<img src="images/back2.jpg" alt="">
				</div>
				<form id="registerForm" method="POST" action="">
					<center><span style="color:red;"></span></center>
					<h3>Registration Form</h3>
					<div class="form-wrapper">
						<label id="fnameLabel" style="display: none;">First Name field Required</label>
						<input id="fname" type="text" placeholder="First Name" class="form-control">
						<i class="zmdi zmdi-account"></i>
					</div>
					<div class="form-wrapper">
						<label id="lnameLabel" style="display: none;">Last Name field Required</label>
						<input id="lname" type="text" placeholder="Last Name" class="form-control">
						<i class="zmdi zmdi-account"></i>
					</div>
					<div class="form-wrapper">
						<label id="emailLabel" style="display: none;">Email Address field Required</label>
						<input id="email" type="email" placeholder="Email Address" class="form-control">
						<i class="zmdi zmdi-email"></i>
					</div>
					<div class="form-wrapper">
						<label id="disabilityLabel" style="display: none;">Disability field requires yes or no</label>
						<select name="disability" id="disability"  class="form-control">
							<option value="1">Disabled?</option>
							<option value="yes">Yes</option>
							<option value="no">No</option>
						</select>
						<i class="zmdi zmdi-caret-down" style="font-size: 17px"></i>
					</div>
					<div class="form-wrapper">
						<label id="passwordLabel" style="display: none;">Password field Required</label>
						<input id="password" type="password" placeholder="Password" class="form-control">
						<i class="zmdi zmdi-lock"></i>
					</div>
					<div class="form-wrapper">
						<label id="confirmPasswordLabel" style="display: none;">Confirm password field Required</label>
						<input id="confirmPassword" type="password" placeholder="Confirm Password" class="form-control">
						<i class="zmdi zmdi-lock"></i>
					</div>
					<button id="register_btn" type="button" name="register_btn">Register
						<i class="zmdi zmdi-arrow-right"></i>
					</button>
					<center><a href="index" class="text-danger" href="">Having account?Login</a></center>
				</form>
			</div>
		</div>
		 <script src="../assets/jquery/jquery.min.js"></script>
		 <script src="../assets/js/articulate.js"></script>

		 <script type="text/javascript">
		 	$(document).ready(()=>{
		 		var fnameLabel = $("#fnameLabel")
		 		var fname = $("#fname")
		 		var lnameLabel = $("#lnameLabel")
		 		var lname = $("#lname")
		 		var emailLabel = $("#emailLabel")
		 		var email = $("#email")
		 		var disabilityLabel = $("#disabilityLabel")
		 		var disability = $("#disability")
		 		var passwordLabel = $("#passwordLabel")
		 		var password = $("#password")
		 		var confirmPasswordLabel = $("#confirmPasswordLabel")
		 		var confirmPassword = $("#confirmPassword")
		 		var register_btn = $("#register_btn")
		 		
	 			register_btn.click(()=>{
	 			if (fname.val() ==="") {
					fnameLabel.css({"color": "red","display":"block"})
				}else{
					fnameLabel.css({"color": " ","display":"none"})
				}
				if (lname.val() ==="") {
					lnameLabel.css({"color": "red","display":"block"})
				}else{
					lnameLabel.css({"color": " ","display":"none"})
				}	
				if (email.val() ==="") {
					emailLabel.css({"color": "red","display":"block"})
				}else{
					emailLabel.css({"color": " ","display":"none"})
				}	
				if (disability.val() ==="1") {
					disabilityLabel.css({"color": "red","display":"block"})
				}else{
					disabilityLabel.css({"color": " ","display":"none"})
				}
				if (password.val() ==="") {
					passwordLabel.css({"color": "red","display":"block"})
				}else{
					passwordLabel.css({"color": " ","display":"none"})
				}
				if (confirmPassword.val() ==="") {
					confirmPasswordLabel.css({"color": "red","display":"block"})
				}else{
					confirmPasswordLabel.css({"color": " ","display":"none"})
				}
				if (fname.val() != "" && lname.val() !="" && password.val() !="" &&
					confirmPassword.val()!="" && disability.val() !="1" && email.val() !="" ) {
						register()
					}
					
		 			})
		 	function register(){
		 		var formdata = new FormData()
		 			formdata.append("fname", fname.val())
		 			formdata.append("lname", lname.val())
		 			formdata.append("email", email.val())
		 			formdata.append("disability", disability.val())
		 			formdata.append("password", password.val())
		 			formdata.append("confirmPassword", confirmPassword.val())
		 			
		 				$.ajax({
		 				type: 'POST',	
		 				url:'../php/register.php',
		 				data: formdata,
		 				 contentType:false,
		 				 processData: false,
		 				success: function(data){
		 					if (data ==="Registration Successful") {
		 						alert(data)
		 						window.location.assign("index")
		 					}else{
		 						alert(data)
		 					}
		 					
		 				}
		 			})
		 	}


		 	})
		 	
		 </script>
	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>