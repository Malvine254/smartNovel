#!C:\Users\Melo\AppData\Local\Programs\Python\Python39\python.exe
import cgi,os
print('Content-type: text/html\r\n\r')
form = cgi.FieldStorage()
string = str(form.getValue("name"))
print('<html>')
print('<body>')
print("<h2>Name\n(%s)</h2>"%string)