<?php 
require 'config.php';
session_start();
$email = $_SESSION['email'];
$text_color = mysqli_real_escape_string($conn,$_POST['text_color']);
$update = $conn->query("UPDATE users SET text_color='$text_color' WHERE email='$email'");
if ($update) {
	echo "color changed";
}else{
	echo "failed";
}



 ?>