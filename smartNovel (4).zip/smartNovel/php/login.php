<?php 

	session_start();
	include "../php/config.php";
	$email = mysqli_real_escape_string($conn,$_POST['email']);
	$password = mysqli_real_escape_string($conn,$_POST['password']);
	$encPassword = md5($password);
	$checkEmail = $conn->query("SELECT  * FROM users WHERE email='$email' AND password='$encPassword'");
	
	if ($checkEmail->num_rows>0) {
		
		$_SESSION['email']=$email;
		echo "success";
		
	}else{
		echo "Incorrect Credentials!!";
		}

	

	


 ?>