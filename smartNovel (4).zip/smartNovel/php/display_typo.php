 <?php 
  require 'config.php';
  $email = $_SESSION['email'];
  $select = $conn->query("SELECT * FROM users WHERE email='$email'");
  if ($select->num_rows>0) {
    while ($row=$select->fetch_assoc()) {
      echo "<div class='list-group-item'>
                            <div class='row align-items-center'>
                                <div class='col'>
                                    <strong class='mb-2'>Change text color</strong>
                                    <p class='text-muted mb-0'>Change text color</p>
                                </div>
                                <div class='col-auto'>
                                    <div class='custom-control custom-switch'>
                                        <select id='text_color' class='form-control'>
                                            <option selected disabled>".$row['text_color']."</option>
                                            <option>Default</option>
                                            <option>Red</option>
                                            <option>Blue</option>
                                            <option>Yellow</option>
                                            <option>Green</option>
                                            <option>Orange</option>
                                            <option>Maroon</option>
                                            <option>Indigo</option>
                                            <option>Violet</option>
                                            <option>Orange</option>
                                            <option>Purple</option>
                                            <option>Skyblue</option>
                                            <option>Teal</option>
                                            <option>Brown</option>
                                            <option>Pink</option>
                                            <option>Silver</option>
                                            <option>Grey</option>
                                        </select>
                                        <span class='custom-control-label'></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class='list-group-item'>
                            <div class='row align-items-center'>
                                <div class='col'>
                                    <strong class='mb-2'>Change Font Size</strong>
                                    <span class='badge badge-pill badge-success'>Enabled</span>
                                    <p class='text-muted mb-0'>Change font size.</p>
                                </div>
                                <div class='col-auto'>
                                    <select id='text_font' class='form-control'>
                                            <option selected disabled>".$row['font_size']."</option>
                                            <option>12</option>
                                            <option>14</option>
                                            <option>16</option>
                                            <option>18</option>
                                            <option>20</option>
                                            <option>22</option>
                                            <option>24</option>
                                            <option>26</option>
                                            <option>28</option>
                                            <option>30</option>
                                            <option>32</option>
                                        </select>
                                </div>
                            </div>
                        </div>
";
    }
  }else{
    echo "no data";
  }






 ?>




 