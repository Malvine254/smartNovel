<?php
include 'config.php'; 
session_start();
$email = mysqli_real_escape_string($conn,$_SESSION['email']);
if (isset($_POST['button1'])) {
	$select = $conn->query("SELECT * FROM draft WHERE email = '$email'");
	if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			$string = $row['status'];
			$array = explode(",", $string);
			$new_status = "1,".$array[1].",".$array[2].",".$array[3];
		 	$update = $conn->query("UPDATE draft SET status='$new_status' WHERE email='$email'");
		 	if ($update) {
		 		echo "updated";
		 	}
			
		}
	}
	
}else if (isset($_POST['button2'])) {
	$select = $conn->query("SELECT * FROM draft WHERE email = '$email'");
	if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			$string = $row['status'];
			$array = explode(",", $string);
			$new_status = $array[0].",1,".$array[2].",".$array[3];
		 	$update = $conn->query("UPDATE draft SET status='$new_status' WHERE email='$email'");
		 	if ($update) {
		 		echo "updated 2";
		 	}
			
		}
	}
	
}else if (isset($_POST['button3'])) {
	$select = $conn->query("SELECT * FROM draft WHERE email = '$email'");
	if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			$string = $row['status'];
			$array = explode(",", $string);
			$new_status = $array[0].",".$array[1].",1,".$array[3];
		 	$update = $conn->query("UPDATE draft SET status='$new_status' WHERE email='$email'");
		 	if ($update) {
		 		echo "updated 3";
		 	}
			
		}
	}
	
}else if (isset($_POST['button4'])) {
	$select = $conn->query("SELECT * FROM draft WHERE email = '$email'");
	if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			$string = $row['status'];
			$array = explode(",", $string);
			$new_status = $array[0].",".$array[1].",".$array[2].",1";
		 	$update = $conn->query("UPDATE draft SET status='$new_status' WHERE email='$email'");
		 	if ($update) {
		 		echo "updated4";
		 	}
			
		}
	}
	
}else if (isset($_POST['discard'])) {
	$delete = $conn->query("DELETE FROM draft WHERE email='$email'");
 	if ($delete) {
 		echo "Novel was discarded";
 	}
	
}



 ?>