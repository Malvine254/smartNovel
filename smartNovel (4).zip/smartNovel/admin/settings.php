<?php require 'php/check_session.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>settings</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../assets/img/favicon.png" rel="icon">
  <link href="../assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="../fontAwesome/all.min.css">
  <link rel="stylesheet" type="text/css" href="../fontAwesome/fontawesome.min.css">

  <!-- Template Main CSS Files -->
  <link href="../assets/css/variables.css" rel="stylesheet">
  <link href="../assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: ZenBlog - v1.3.0
  * Template URL: https://bootstrapmade.com/zenblog-bootstrap-blog-template/
  * Author: BootstrapMade.com
  * License: https:///bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1>Admin</h1>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index">DASHBOARD</a></li>
          <li><a href="tables">TABLES</a></li>
          <li><a href="forms">FORMS</a></li>
          <li><a href="reports">REPORTS</a></li>
          <li class="dropdown"><a href="editorial"><span>EDITORIAL</span> <span class="text-danger">[<?php include 'php/notification_counter.php'; ?>]</span><i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
                <?php include 'php/new_notification.php'; ?>
            </ul>
          </li>
          <li><a href="php/logout">LOGOUT</a></li>
        </ul>
      </nav><!-- .navbar -->

      <div class="position-relative">
        <a href="#" class="mx-2"><span class="bi-facebook"></span></a>
        <a href="#" class="mx-2"><span class="bi-twitter"></span></a>
        <a href="#" class="mx-2"><span class="bi-instagram"></span></a>

        <a  href="#" class="mx-2 js-search-open"  id="searchButton"><span  class="bi-search"></span></a>
        <i  class="bi bi-list mobile-nav-toggle"></i>
        <a href="#" class="mx-2"><?php include 'php/display_image.php'; ?></a>

        <!-- ======= Search Form ======= -->
        <div class="search-form-wrap js-search-form-wrap">
          <form action="search-result.html" class="search-form">
            <span class="icon bi-search"></span>
            <h1 id="textToSearch" style="display: none;">Please, enter text to search.</h1>
            <input id="searchMe" type="text" placeholder="Search" class="form-control">
            <button  class="btn js-search-close"><span class="bi-x"></span></button>
          </form>
        </div><!-- End Search Form -->

      </div>

    </div>

  </header><!-- End Header -->

  <main id="main">
    <section>
      <div class="container" data-aos="fade-up">
        <div class="row">
          <div class="col-lg-12 text-center mb-5">
            <h3 class="">Admin Settings and Preferences</h3>
          </div>
        </div>
        <div class="container">
          <div class="row justify-content-center">
            <div class=" col-lg-10 col-xl-10 mx-auto">
                <div class="my-4">
                <ul class="nav nav-tabs mb-4" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link" id="homeTab" data-toggle="tab" role="tab" aria-controls="home" aria-selected="true">Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " id="securityTab" data-toggle="tab" role="tab" aria-controls="profile" aria-selected="false">Security</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="voiceTab" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">Voice Assistance</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="typogrTab" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">Typography</a>
                    </li>
                </ul>
                <!-- start of profile settings -->
                <div id="hideProfile">
                    <div class="row mb-3">
                        <div class="col-md-8">
                            <h5 class="mb-0 ">Profile Settings</h5>
                            <p>These settings are helps you keep your account secure.</p>
                        </div>
                        <div class="col-md-4">
                            
                            
                            <form enctype="multipart/form-data" method="POST" >
                                <input id="profile2" type="file" style="display: none;" name="profile">
                                <button type="button" class="fa fa-camera btn" id="ButtonShow"></button>
                            </form>
                           
                        </div>
                    </div>
                    <div class="list-group mb-5 shadow">
                         <form  id="formClear"> 
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col">
                                    <strong class="mb-2">Change Password</strong>
                                    <div class="row">
                                        
                                        <div class="col-md-6">
                                             <input id="old_password" type="text" class="form-control " placeholder="Old Password">
                                        </div>
                                         <div class="col-md-6">
                                             <input id="new_password" type="text" class="form-control " placeholder="New Password">
                                        </div>
                                       
                                    </div>
                                   
                                </div>
                                <div class="col-auto">
                                    <br>
                                    <div class="custom-control custom-switch">
                                        <input type="button" class="btn btn-primary btn-sm" id="changePassBtn" value="Change Password">
                                        <span class="custom-control-label"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        </form>
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col">
                                    <strong class="mb-2">Delete Account</strong>
                                    <span class="badge badge-pill badge-success">Enabled</span>
                                    <p class="text-muted mb-0">Once deleted can never be recoverd.</p>
                                </div>
                                <div class="col-auto">
                                    <button class="btn btn-danger btn-sm">Delete Account</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end of profile settings -->

                 <!-- start of security settings -->
                <div id="hideSecurity"  style="display: none;">
                    <h5 class="mb-0 mt-5">Action Center</h5>
                    <div class="list-group mb-5 shadow">
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col">
                                    <strong class="mb-2">Enable Activity Logs</strong>
                                    <p class="text-muted mb-0">Donec id elit non mi porta gravida at eget metus.</p>
                                </div>
                                <div class="col-auto">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="activityLog" checked="">
                                        <span class="custom-control-label"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col">
                                    <strong class="mb-2">2FA Authentication</strong>
                                    <span class="badge badge-pill badge-success">Enabled</span>
                                    <p class="text-muted mb-0">Maecenas sed diam eget risus varius blandit.</p>
                                </div>
                                <div class="col-auto">
                                    <button class="btn btn-primary btn-sm">Disable</button>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col">
                                    <strong class="mb-2">Activate Pin Code</strong>
                                    <p class="text-muted mb-0">Donec id elit non mi porta gravida at eget metus.</p>
                                </div>
                                <div class="col-auto">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="pinCode">
                                        <span class="custom-control-label"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end of security settings -->

                 <!-- start of voice assistance settings -->
                <div id="hideVoiceAssistance"  style="display: none;">
                    <h5 class="mb-0 mt-5">Voice Assistance Settings</h5>
                    <p>These settings are helps you keep your account secure.</p>
                    <div class="list-group mb-5 shadow">
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col">
                                    <strong class="mb-2">Disable Voice Assistance</strong>
                                    <p class="text-muted mb-0">Voice assistance is enabled.</p>
                                </div>
                                <div class="col-auto">
                                    <div class="custom-control custom-switch">
                                        
                                        
                                        <span class="custom-control-label"></span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col">
                                    <strong class="mb-2">Voice Assistance Speed</strong>
                                    <span class="badge badge-pill badge-success">5</span>
                                    <p class="text-muted mb-0">Change speed of artuclation.</p>
                                </div>
                                <div class="col-auto">
                                    
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end of voice assistance settings -->

                 <!-- start of Typography settings -->
                <div id="hideTypography" style="display: none;">
                    <h5 class="mb-0 mt-5">Typography Settings</h5>
                    <p>Change text color.</p>
                    <div class="list-group mb-5 shadow">
                      
                    </div>
                </div>
                <!-- end of typography settings -->
            </div>
        </div>
    </div>
    </div>

      </div>
    </section>

    

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>
  <script src="../assets/jquery/jquery.min.js"></script>
  <script src="../assets/js/articulate.js"></script>
   <script src="../assets/js/settings1.js"></script>
  <script type="text/javascript">
      var homeTab,securityTab,voiceTab,typogrTab,hideProfile,hideSecurity,hideVoiceAssistance,hideTypography
      homeTab =$("#homeTab")
      securityTab = $("#securityTab")
      voiceTab = $("#voiceTab")
      typogrTab = $("#typogrTab")
      hideProfile = $("#hideProfile")
      hideSecurity= $("#hideSecurity")
      hideVoiceAssistance = $("#hideVoiceAssistance")
      hideTypography = $("#hideTypography")

      homeTab.click(function(){
        // homeTab.addClass('active')
        // securityTab.removeClass('active')
        // voiceTab.removeClass('active')
        // typogrTab.removeClass('active')


        hideProfile.css({"display":"block"})
        hideTypography.css({"display":"none"})
        hideVoiceAssistance.css({"display":"none"})
        hideSecurity.css({"display":"none"})
      })
      securityTab.click(function(){
        // homeTab.removeClass('active')
        // securityTab.addClass('active')
        // voiceTab.removeClass('active')
        // typogrTab.removeClass('active')

        hideProfile.css({"display":"none"})
        hideTypography.css({"display":"none"})
        hideVoiceAssistance.css({"display":"none"})
        hideSecurity.css({"display":"block"})
      })
      voiceTab.click(function(){
        // securityTab.click(function(){
        // homeTab.removeClass('active')
        // securityTab.removeClass('active')
        // voiceTab.addClass('active')
        // typogrTab.removeClass('active')

        hideProfile.css({"display":"none"})
        hideTypography.css({"display":"none"})
        hideVoiceAssistance.css({"display":"block"})
        hideSecurity.css({"display":"none"})
      })
       typogrTab.click(function(){
        // securityTab.click(function(){
        // homeTab.removeClass('active')
        // securityTab.removeClass('active')
        // voiceTab.removeClass('active')
        // typogrTab.addClass('active')

        hideProfile.css({"display":"none"})
        hideTypography.css({"display":"block"})
        hideVoiceAssistance.css({"display":"none"})
        hideSecurity.css({"display":"none"})
      })

       //update password
       function updatePass(){
        
        $("#changePassBtn").click(function(){
            var old_password = $("#old_password").val()
            var new_password = $("#new_password").val()
            if (old_password ==="") {
                $("#old_password").addClass('border-danger')
            }else{
                $("#old_password").removeClass('border-danger')
            }
             if (new_password ==="") {
                $("#new_password").addClass('border-danger')
            }else{
                $("#new_password").removeClass('border-danger')
            }
             if (new_password !="" && old_password !="") {
                //alert('true')
                var fd = new FormData()
                fd.append("old_password",old_password)
                fd.append("new_password",new_password)
                $.ajax({
                    url: 'php/change_password.php',
                    type: 'POST',
                    data: fd,
                    contentType:false,
                    processData: false,
                    success:function(data){
                        alert(data)
                        $("#formClear")[0].reset()
                    }
                })
               }
                
            })

        }

        
       updatePass()
       //change text color
       $("#text_color").change(function(){
        var text_color = ($(this).val())
        var fd2 = new FormData()
        fd2.append("text_color",text_color)
        $.ajax({
            url: 'php/change_text_color.php',
            type: 'POST',
            data: fd2,
            contentType:false,
            processData: false,
            success:function(data){
                alert(data)
                //$("#formClear")[0].reset()
            }
        })
       })
       //change font size
       $("#text_font").change(function(){
        var font_size = ($(this).val())
        var fd2 = new FormData()
        fd2.append("font_size",font_size)
        $.ajax({
            url: 'php/change_font.php',
            type: 'POST',
            data: fd2,
            contentType:false,
            processData: false,
            success:function(data){
                alert(data)
                //$("#formClear")[0].reset()
            }
        })
       })

       //change voice speed

       $("#speed").keyup(function(){
        var speed = $(this).text()
        var fd3 = new FormData()
        fd3.append("speed",speed)
        $.ajax({
            url: 'php/voice_speed.php',
            type: 'POST',
            data: fd3,
            contentType:false,
            processData: false,
            success:function(data){
                //alert(data)
                //$("#formClear")[0].reset()
            }
        })
       })

       //disable voice note
       $("#disable").change(function(){
         var fd4 = new FormData()
        if ($(this).is(":checked")) {
            fd4.append("disable",0)
            $.ajax({
                url: 'php/disable_voice.php',
                type: 'POST',
                data: fd4,
                contentType:false,
                processData: false,
                success:function(data){
                    alert(data)
                    //$("#formClear")[0].reset()
                }
            })
            
        }else{
            fd4.append("disable",1)
            $.ajax({
                url: 'php/disable_voice.php',
                type: 'POST',
                data: fd4,
                contentType:false,
                processData: false,
                success:function(data){
                    alert(data)
                    //$("#formClear")[0].reset()
                }
            })
        }

       })
       //change profile

       //profile ButtonShow
       $("#ButtonShow").click(function(){
        $("#profile2").click();
         

        
       })
       $("#profile2").change(function(){
           console.log("changed")
            var fd6 = new FormData()
            var profile = $("#profile2")[0].files
            fd6.append('profile',profile[0])
            $.ajax({
              url:"php/change_profile.php",
              type: "post",
              data:fd6,
              contentType:false,
              processData: false,
              success: function(response){
                alert(response)
                //$("#profile2")[0].reset()
              }
          })
        })
      // search

     $(document).keypress(function(e){

            var key = (event.keyCode ? event.keyCode : event.which);
            var ch = String.fromCharCode(key)
             var search =  $("#searchMe").val()
           if (ch==='5') {
            //console.log(ch)
            $("#searchButton")[0].click("click")
            articulateRate($("#textToSearch"))
            disableVoice($("#textToSearch"))
            setTimeout(function(){
              $("#searchMe").focus()

            },100)
            
            //$("#searchMe").focus()id="searchButton"
           }else if(ch==='3'){
            setInterval(()=>{
               //alert("success")
                  window.location.assign("search-result.php?search="+search)
                  $("#searchMe").blur()
            
              
            },2000)

           }

          })
             // change color
     changeColor($('body'))
     // change font
     changeFontSize($('body'))

  </script>

</body>

</html>