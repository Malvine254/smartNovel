<?php 
require 'config.php';
session_start();
$email = $_SESSION['email'];
$old_password = mysqli_real_escape_string($conn,$_POST['old_password']);
$new_password = mysqli_real_escape_string($conn,$_POST['new_password']);
$final_new_pass = md5($new_password);
$final_old_pass = md5($old_password);
$dbPass = $conn->query("SELECT * FROM users WHERE password='$final_old_pass' AND email='$email'");
if ($dbPass->num_rows>0) {
	$updatePass = $conn->query("UPDATE users SET password='$final_new_pass'");
	if ($updatePass) {
		echo "Password was changed";
	}else{
		echo "failed";
	}
}else{
	echo "Old password is incorrect!!";
}

 ?>