<?php 
include '../php/config.php';
$numbering = 1;
$query = $conn->query("SELECT * FROM users");
while ($row=$query->fetch_assoc()) {
	echo " <tr>
            <td>".$numbering++."</td>
            <td>".$row['fname']." ".$row['lname']."</td>
            <td>".$row['email']."</td>
            <td>".checkDisabilityStatus($row['disable'])."</td>
            <td><button type='button' class='deleteusers btn btn-light' value='".$row['id']."'><i class='fa fa-trash'></i></button></td>
          </tr>


	";



}
function checkDisabilityStatus($status){
    if ($status==="1") {
        return "<p class='btn btn-success col-md-8'>Disabled</p>";
    }else{
        return "<p class='btn btn-primary col-md-8'>Not disabled</p>";  
    }

}
 ?>