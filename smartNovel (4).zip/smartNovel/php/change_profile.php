<?php 
require 'config.php';
session_start();
$email = $_SESSION['email'];
$profile = mysqli_real_escape_string($conn,$_FILES['profile']['name']);
$target = '../assets/img/profile/'.basename($profile);
if (move_uploaded_file($_FILES['profile']['tmp_name'], $target)) {
	$updatePass = $conn->query("UPDATE users SET profile='$profile' WHERE email='$email'");
	if ($updatePass) {
		echo "Profile Updated";
	}else{
		echo "failed";
	}
}else{
	echo "failed";
}


 ?>