<?php 
include 'config.php';
//if (isset($_SESSION['email'])) {
  session_start();
 $email = $_SESSION['email']; 
 $selectDraft = $conn->query("SELECT * FROM draft WHERE email='$email' ");
  if ($selectDraft->num_rows>0) {
    while ($row2 =$selectDraft->fetch_assoc()) {
    $db_body = $row2['body'];
    $db_title = $row2['title'];
    $db_category = $row2['category'];
    $db_image = $row2['image'];
    $db_date = $row2['date']; 
    $array  = [$db_body , $db_title , $db_category, $db_image];
    print_r(json_encode($array));
  }
//  }
}else{
     echo " ";
  }


?>