<?php 
session_start();
require 'config.php';
$email = mysqli_real_escape_string($conn,$_SESSION['email']);
$select = $conn->query("SELECT * FROM articles WHERE email = '$email' AND status='0' LIMIT 1");
if ($select->num_rows>0) {
	while ($row=$select->fetch_assoc()) {
		if (isset($_POST['span'])) {
			$sql = $conn->query("UPDATE articles SET status='1' WHERE email = '$email' AND status='0'");
		}
		echo $row['status'];
	}
}else{
	echo ""; 
}


 ?>