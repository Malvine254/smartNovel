<?php 
if ($_POST['fullName'] !="" && $_FILES['profileImage']!="") {
	include '../../php/config.php';
date_default_timezone_set('Africa/Nairobi');
session_start();
$fullName = mysqli_real_escape_string($conn,$_POST['fullName']);
$image = mysqli_real_escape_string($conn,$_FILES['profileImage']['name']);
$target = "../../assets/img/profile/".basename($image);
$email = $_SESSION['admin_email'];
echo $fullName;
if (move_uploaded_file($_FILES['profileImage']['tmp_name'], $target)) {
	$update = $conn->query("UPDATE admin SET name='$fullName', profile='$image' WHERE email='$email'");
	if ($update) {
		echo "Account Edited Successsfully".$fullName;
	}else{
		echo "failed";
	}

}
}else{
	echo "not set";
}



	



 ?>