 <?php 
if (isset($_GET['search'])) {
  require 'config.php';
  $numbering = 1;
  $id = strtolower(mysqli_real_escape_string($conn,$_GET['search']));
  $select = $conn->query("SELECT * FROM articles WHERE LOWER(title) LIKE '%$id%'");
  if ($select->num_rows>0) {
    while ($row=$select->fetch_assoc()) {
      echo "

      <p style='display:none;' class='searchTitle'>Press ".$numbering++.", to read novel on  ".$row['title'].".</p>
      <p style='display:none;' class='getId'>".$row['id_auto']."</p>
      <div class='d-md-flex post-entry-2 small-img '>
              <a href='single-post?id=".$row['id_auto']."' class='me-4 thumbnail '>
                <img style='height:350px; width:600px;' src='".$row['image']."' alt='' class='img-fluid'>
              </a>
              <div>
                <div class='post-meta'><span class='date'>Business</span> <span class='mx-1'>&bullet;</span> <span>".$row['date']."</span></div>
                <h3><a class='clickedLink' href='single-post?id=".$row['id']."'>".$row['title']."</a></h3>
                <p>".substr($row['body'], 0,700)." <a href='single-post?id=".$row['id_auto']."' class='text-danger'>read more...</a></p>
                <div class='d-flex align-items-center author'>
                  <div class='photo'><img style='border-radius: 50%; width: 65px;height: 65px;' src='assets/img/profile/".$row['profile']."' alt=' class='img-fluid'></div>
                  <div class='name'>
                    <h3 class='m-0 p-0'>".$row['author']."</h3>
                  </div>
                </div>
              </div>
            </div> ";
    }
  }else{
    echo " <p style='display:none;' class='searchTitle text-center text-danger'>Unfortunately, No search result was found that matches your search. Try again using different search parameters.</p><p class='text-center text-danger'>No results were found</p>";
  }



  
  }







 ?>