<?php 
require '../php/config.php';
$select = $conn->query("SELECT * FROM categories");
if ($select->num_rows>0) {
	while ($row=$select->fetch_assoc()) {
		echo "<option value='".$row['category']."'>".$row['category']."</option>";
	}
}else{
	echo "<option disabled>No category found</option>";
}


 ?>