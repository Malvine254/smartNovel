<?php 
require 'config.php';
session_start();
$email = $_SESSION['email'];
$disable = mysqli_real_escape_string($conn,$_POST['disable']);
$update = $conn->query("UPDATE users SET disable='$disable' WHERE email='$email'");
if ($update) {
	echo "Voice Speed changed";
}else{
	echo "failed";
}



 ?>