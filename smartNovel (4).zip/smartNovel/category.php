<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Categories</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="fontAwesome/all.min.css">
  <link rel="stylesheet" type="text/css" href="fontAwesome/fontawesome.min.css">
  <link rel="stylesheet" type="text/css" href="modal/modal1.css">

  <!-- Template Main CSS Files -->
  <link href="assets/css/variables.css" rel="stylesheet">
  <link href="assets/css/main.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: ZenBlog - v1.3.0
  * Template URL: https://bootstrapmade.com/zenblog-bootstrap-blog-template/
  * Author: BootstrapMade.com
  * License: https:///bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <div id="loading">
    <img width="45px" height="45px" id="loader-image" src="loader/loader.gif">
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1>SmartNovel</h1>
      </a>

       <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index">HOME</a></li>
          <li class="dropdown"><a href="category"><span><u>CATEGORIES</u></span><i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
             <?php include 'php/display_category.php'; ?>
            </ul>
          </li>
          <li><a href="create">CREATE NOVEL</a></li>
          <li><a href="settings">SETTINGS</a></li>
           <li><a id="logOut">LOGOUT</a></li>
        </ul>
      </nav><!-- .navbar -->

      <div class="position-relative">
        <a href="#" class="mx-2"><span class="bi-facebook"></span></a>
        <a href="#" class="mx-2"><span class="bi-twitter"></span></a>
        <a href="#" class="mx-2"><span class="bi-instagram"></span></a>

       <a  href="#" class="mx-2 js-search-open"  id="searchButton"><span  class="bi-search"></span></a>
        <i  class="bi bi-list mobile-nav-toggle"></i>

        <!-- ======= Search Form ======= -->
        <div class="search-form-wrap js-search-form-wrap">
          <form action="search-result.html" class="search-form">
            <span class="icon bi-search"></span>
            <h1 id="textToSearch" style="display: none;">Please, enter text to search.</h1>
            <input id="searchMe" type="text" placeholder="Search" class="form-control">
            <button  class="btn js-search-close"><span class="bi-x"></span></button>
          </form>
        </div><!-- End Search Form -->

      </div>

    </div>

  </header><!-- End Header -->

</style>
  <main id="main">
    <section>
      <div class="container ">
        <div class="row">

          <div class="col-md-12" data-aos="fade-up">
            <h2 class="category-title"> <span><?php if (isset($_GET['id'])) {
             echo "Category: ".$_GET['id'];
            } ?></span></h2>

         <?php
          require 'php/config.php';
          if (isset($_GET['id'])) {
             $id =  strtolower(mysqli_real_escape_string($conn,$_GET['id']));
             $select = $conn->query("SELECT * FROM articles WHERE LOWER(category) LIKE '%$id%'");
              if ($select->num_rows>0) {
                while ($row=$select->fetch_assoc()) {
                  echo limitWords($row['body'],$row['id_auto'],$row['image'],$row['category'],$row['date'],$row['title'],$row['body'],$row['author'],$row['profile']);
                }
              }else{
                echo "no data";
              }
           }else{ 
          $select = $conn->query("SELECT * FROM articles ");
          if ($select->num_rows>0) {
            while ($row=$select->fetch_assoc()) {
              echo limitWords($row['body'],$row['id_auto'],$row['image'],$row['category'],$row['date'],$row['title'],$row['body'],$row['author'],$row['profile']);
            }
          }else{
            echo "no data";
          }
          }



function limitWords($length,$id,$image,$category,$date,$title,$body,$author,$profile){
  if (strlen($length)>700) {
    $text = "";
    $text = "<div class='d-md-flex post-entry-2 half shadow'>
              <a href='single-post?id=".$id."' class='me-4 thumbnail'>
                <img style='height:600px; width:600px;' src='assets/img/articles/".$image."' alt='' class='img-fluid'>
              </a>
              <div>
                <div class='post-meta'><span class='date'>".$category."</span> <span class='mx-1'>&bullet;</span> <span>".$date."</span></div>
                <h3><a href='single-post?id=".$id."'>".$title."</a></h3>
                <p style='padding:10px;'>".substr($body, 0,700)."<a class='text-danger' href='single-post?id=".$id."'> read more...</a></p>
                <div class='d-flex align-items-center author'>
                  <div class='photo'><img style='border-radius: 50%; width: 50px; height: 50px;' src='assets/img/profile/".$profile."' alt='' class='img-fluid'></div>
                  <div class='name'>
                    <h3 class='m-0 p-0'>".$author."</h3>
                  </div>
                </div>
              </div>
            </div>";
  }else{
   $text = "<div class='d-md-flex post-entry-2 half shadow'>
              <a href='single-post?id=".$id."' class='me-4 thumbnail'>
                <img style='height:600px; width:600px;' src='".$image."' alt='' class='img-fluid'>
              </a>
              <div>
                <div class='post-meta'><span class='date'>".$category."</span> <span class='mx-1'>&bullet;</span> <span>".$date."</span></div>
                <h3><a href='single-post?id=".$id."'>".$title."</a></h3>
                ".$body."<a class='text-danger'></p>
                <div class='d-flex align-items-center author'>
                  <div class='photo'><img height='200' width='100' src='assets/img/profile/".$profile."' alt='' class='img-fluid'></div>
                  <div class='name'>
                    <h3 class='m-0 p-0'>".$author."</h3>
                  </div>
                </div>
              </div>
            </div>";
  }
  return $text;

}

function boldFirstLetter($string){
  $new_string = "";
  $final = strlen($string);
  for ($i=0; $i < $final; ++$i) { 
    if ($i<4) {
      $new_string .='<span class="h1">'.$string[$i].'</span>';
    }else{
      $new_string .= $string[$i];
    }
  }
  return $new_string;

}




 ?>

           
      

        </div>
      </div>
    </section>
  </main><!-- End #main --> 
  <!-- Trigger/Open The Modal -->
<!-- <button id="myBtn">Open Modal</button> -->

<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <div id="modelContent">
     
    </div>
  </div>

</div>

  
    

  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="assets/jquery/jquery.min.js"></script>
  <script src="assets/js/articulate.js"></script>
  <script src="assets/js/settings1.js"></script>
  <script type="text/javascript" src="modal/modal.js"></script>
  <script>
    $(document).ready(()=>{
       if (window.loaded=true) {
         $("#loading").css("display","none");
      }
    

     $(document).keypress(function(e){

            var key = (event.keyCode ? event.keyCode : event.which);
            var ch = String.fromCharCode(key)
             var search =  $("#searchMe").val()
           if (ch==='5') {
            //console.log(ch)
            $("#searchButton")[0].click("click")
            // enable disable articulate
            articulateRate($("#textToSearch"))
            disableVoice($("#textToSearch"))

           
            setTimeout(function(){
              $("#searchMe").focus()

            },100)
            
            //$("#searchMe").focus()id="searchButton"
           }else if(ch==='3'){
            setInterval(()=>{
               //alert("success")
                  window.location.assign("search-result.php?search="+search)
                  $("#searchMe").blur()
            
              
            },2000)

           }

          })

     // change color
     changeColor($('body'))
     // change font
     changeFontSize($('body'))
     

    })
  </script>

</body>

</html>