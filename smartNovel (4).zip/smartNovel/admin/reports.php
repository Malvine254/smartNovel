<?php require 'php/check_session.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>reports</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@400;500&family=Inter:wght@400;500&family=Playfair+Display:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS Files -->
  <link href="../assets/css/variables.css" rel="stylesheet">
  <link href="../assets/css/main.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="../fontAwesome/all.min.css">
  <link rel="stylesheet" type="text/css" href="../fontAwesome/fontawesome.min.css">

  <!-- =======================================================
  * Template Name: ZenBlog - v1.3.0
  * Template URL: https://bootstrapmade.com/zenblog-bootstrap-blog-template/
  * Author: BootstrapMade.com
  * License: https:///bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1>Admin</h1>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index">DASHBOARD</a></li>
          <li><a href="tables">TABLES</a></li>
          <li><a href="forms">FORMS</a></li>
          <li><a href="reports">REPORTS</a></li>
          <li class="dropdown"><a href="editorial"><span>EDITORIAL</span> <span class="text-danger">[<span id="showCounter">0</span>]</span><i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
                <span id="newNotification"></span>
            </ul>
          </li>
          <li><a href="php/logout">LOGOUT</a></li>
        </ul>
      </nav><!-- .navbar -->
      <style type="text/css">
      a{
        text-transform: uppercase;
      }
      </style>
      <div class="position-relative">
        <a href="#" class="mx-2"><span class="bi-facebook"></span></a>
        <a href="#" class="mx-2"><span class="bi-twitter"></span></a>
        <a href="#" class="mx-2"><span class="bi-instagram"></span></a>
        <a  href="#" class="mx-2 js-search-open"  id="searchButton"><span  class="bi-search"></span></a>
        <i  class="bi bi-list mobile-nav-toggle"></i>
        <a href="#" class="mx-2"><?php include 'php/display_image.php'; ?></a>

        <!-- ======= Search Form ======= -->
        <div class="search-form-wrap js-search-form-wrap">
          <form action="search-result.html" class="search-form">
            <span class="icon bi-search"></span>
            <h1 id="textToSearch" style="display: none;">Please, enter text to search.</h1>
            <input id="searchMe" type="text" placeholder="Search" class="form-control">
            <button  class="btn js-search-close"><span class="bi-x"></span></button>
          </form>
        </div><!-- End Search Form -->

      </div>

    </div>

  </header><!-- End Header -->

  <main id="main">
    <section>
      <div class="container" data-aos="fade-up">
        <div class="row">
        </div>
        <div class="container">
          <div class="row justify-content-center">
            <div class=" col-lg-10 col-xl-10 mx-auto">
                <div class="my-4">
                <ul class="nav nav-tabs mb-4" id="myTab" role="tablist">
                    <li class="nav-item">
                       <a class="links nav-link" href="?type=Daily Report" id="dailyTab" data-toggle="tab" role="tab" aria-controls="home" aria-selected="true">Daily Report</a>
                    </li>
                    <li class="nav-item">
                        <a class="links nav-link " href="?type=Weekly Report" id="weeklyTab" data-toggle="tab" role="tab" aria-controls="profile" aria-selected="false">Weekly Report</a>
                    </li>
                    <li class="nav-item">
                        <a class="links nav-link" href="?type=Monthly Report" id="monthlyTab" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">Monthly Report</a>
                    </li>
                     <li class="nav-item">
                        <a class="links nav-link" href="?type=Annual Report" id="annualTab" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">Annual Report</a>
                    </li>
                </ul>
                <!-- start of user table -->
                <div id="userTable">
                    <div class="row mb-3">
                        
                    </div>
                    <div class="list-group mb-5 shadow">
                         <form > 
                        <div id="tablePrintable" class="list-group-item">
                            <div class="row align-items-center">
                                <div id="printContent" class="col" style="height: 400px; overflow-y: scroll;">
                                    <strong id="tableTitle" class="mb-2 text-success"><?php if (isset($_GET['type'])) {echo $_GET['type'];}else{echo "All Reports"; } ?></strong>
                                    <table class="table table-bordered">
                                      <tr>
                                         <th>#</th>
                                         <th>Book Title</th>
                                         <th>Author</th>
                                         <th>Date Posted</th>
                                         <th>Frequency</th>
                                         <th>Category</th>
                                         <th id="hide">Action</th>
                                      </tr>
                                    <?php include 'php/report.php'; ?>
                                    </table>
                                   
                                    
                                    </div>
                                   
                                </div><br>
                            </div><br>
                            <center><input type="button" class="btn btn-primary btn-sm" id="printReports" value="Print <?php if (isset($_GET['type'])) {echo $_GET['type'];}else{echo "Daily Reports"; } ?>"></center><br>
                        </form>
                    </div>
                </div>
                <!-- end of user table -->

                  
  <!-- ======= Footer ======= -->

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>
  <script src="../assets/jquery/jquery.min.js"></script>
  <script src="js/tables9.js"></script>
   <script src="js/tables05.js"></script>
  <script>
   $(document).ready(()=>{
    var tablePrintable = $("#tablePrintable") 
    var printReports = $("#printReports")
    printReports.click(()=>{
        $("#hide").css({"visibility":"hidden"})
         $(".hide2").css({"visibility":"hidden"})
        var newWin = window.open("")
        newWin.document.write('<html><head><title></title><link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet"> </head><body>')
         newWin.document.write(tablePrintable.html())
         newWin.document.write('</body></html>')

        newWin.print()
        newWin.close()

    })


   }) 
  
   
    
    
  </script>

</body>

</html>