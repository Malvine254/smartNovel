<?php 
require 'config.php';
session_start();
$email = $_SESSION['email'];
$font_size = mysqli_real_escape_string($conn,$_POST['font_size']);
$update = $conn->query("UPDATE users SET font_size='$font_size' WHERE email='$email'");
if ($update) {
	echo "Font size changed";
}else{
	echo "failed";
}



 ?>