<?php 
if (isset($_POST['id'])) {
	include '../../php/config.php';
	$id = $_POST['id'];
	$del = $conn->query("DELETE FROM users WHERE id='$id'");
	if ($del) {
		echo "Deleted";
	}else{
		echo "failed";
	}
}




 ?>