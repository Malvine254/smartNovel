<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Login</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		
		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">

		<!-- STYLE CSS --> 
		<link rel="stylesheet" href="css/style.css">
	</head>

	<body>

		<div class="wrapper" style="background-image: url('images/back.jpg');">
			<div class="inner">
				<div class="image-holder">
					<img src="images/bg-registration-form-2.jpg" alt="">
				</div>
				<form method="POST" action="">
					<h3>Login Form</h3>
					<div class="form-wrapper">
						<label id="emailLabel" style="display: none;">Email Address field Required!!</label>
						<input id="email" name="email" type="text" placeholder="Email Address" class="form-control">
						<i class="zmdi zmdi-account"></i>
					</div>
					
					<div class="form-wrapper">
						<label id="passwordLabel" style="display: none;">Password field Required!!</label>
						<input id="password" name="password" type="password" placeholder="Password" class="form-control">
						<i class="zmdi zmdi-lock"></i>
					</div>
					<button type="button" id="login_btn" name="login_btn">Login
						<i class="zmdi zmdi-arrow-right"></i>
					</button><br>
					<center><a href="register" class="text-danger" href="">Not having account?Register</a></center>
				</form>
			</div>
		</div>
		<p id="regInstructions" style="display: none;">Hello, Welcome to Smart Novel, the following are instructions to aid you in your Log in process:
		Note: Making entries will take 30 seconds each so concentration is paramount.	
		Finally, Press 5, to disable voice assistance.</p>
		<p id="failed" style="display: none;"> Incorrect Credentials. Press 1 to try again.</p>
		<p id="inputs" style="display: none;"> Input fields cannot be empty.</p>
		<script src="../assets/jquery/jquery.min.js"></script>
		 <script src="../assets/js/articulate.js"></script>

<script type="text/javascript">
$(document).ready(()=>{
	function login(){
		let email = $("#email")
		let password = $("#password")
		let login_btn = $("#login_btn")
		let emailLabel = $("#emailLabel")
		let passwordLabel = $("#passwordLabel")
		login_btn.click(()=>{
		if (email.val() ==="") {
			emailLabel.css({"color": "red","display":"block"})
		}else{
			emailLabel.css({"color": " ","display":"none"})
		}
		if (password.val() ==="") {
			passwordLabel.css({"color": "red","display":"block"})
		}else{
			passwordLabel.css({"color": " ","display":"none"})
		}
		if (email.val() !="" && password.val() !="") {
			var formdata = new FormData()
			formdata.append("email", email.val())
			formdata.append("password", password.val())
			$.ajax({
			type: 'POST',	
			url:'../php/login.php',
			data: formdata,
			contentType:false,
			processData: false,
			success: function(data){
				if (data==='success') {
					window.location.assign('../index')
				}else{
					alert(data)
				}
				
				
			}
		})

		}		
		
		})

	}
	 login()


})

</script>
		
	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>