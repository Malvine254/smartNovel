<?php 
require '../../php/config.php';
$select = $conn->query("SELECT * FROM draft WHERE new='0'");
if ($select->num_rows>0) {
    while ($row=$select->fetch_assoc()) {
        $id = $row['id'];
         
    }
    echo " <li><a href='editorial?i=".$id."' id='".$id."' class='clicked'>You have ".$select->num_rows." Pending new novel </strong></a></li>";

}


 ?>