<?php 
session_start();
if (isset($_SESSION['email'])) {
    // code...
}else{
    header('location:login/index');
}


 ?>