<?php 
date_default_timezone_set("Africa/Nairobi");
session_start();
require 'config.php';
if (isset($_POST['title']) && isset($_POST['body'])  && isset($_POST['category']) && isset($_POST['fileName'])) {
	$title = mysqli_real_escape_string($conn, $_POST['title']);
	$file = mysqli_real_escape_string($conn,$_FILES['files']['name']);
	$body = mysqli_real_escape_string($conn, $_POST['body']);
	$category = mysqli_real_escape_string($conn, $_POST['category']);
	$email = mysqli_real_escape_string($conn, $_SESSION['email']);
	$target = "../assets/img/articles/".basename($file);
	$id = rand(6000,5000000);
	$target2 = "assets/img/articles/".basename($file);
	$select = $conn->query("SELECT * FROM users WHERE email='$email'");
	while ($row=$select->fetch_assoc()) {
		$name = $row['fname']." ".$row['lname'];
		$profile = $row['profile'];
		$date = date('d-m-y');
		$time_stamp = time();
	if (move_uploaded_file($_FILES['files']['tmp_name'], $target)) {
		$insert = $conn->query("INSERT INTO articles(title,body,category,author,`date`,profile,time_stamp,image,id_auto) VALUES('$title','$body','$category','$name','$date','$profile','$time_stamp','$target2','$id')");
		if ($insert) {
			echo "Novel was submitted Successfully";
		}else{
			echo "server error";
		}
	}
	
}
}




 ?>