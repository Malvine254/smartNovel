<?php 
include '../php/config.php';
$numbering = 1;
$query = $conn->query("SELECT * FROM categories");
while ($row=$query->fetch_assoc()) {
	echo " <tr>
            <td>".$numbering++."</td>
            <td>".$row['category']."</td>
            <td><button type='button' class='deletecategory btn btn-light' value='".$row['id']."'><i class='fa fa-trash'></i></button></td>
          </tr>


	";

}
 ?>