$(document).ready(()=>{

       
        function deleteUsers(){
          var deleteusers = $(".deleteusers")
          deleteusers.click(function(){
          var id = $(this).val()
          var formdata = new FormData()
          formdata.append("id",id)
          $.ajax({
          url:"php/delete_users.php",
          type: "post",
          data:formdata,
          contentType:false,
          processData: false,
          success: function(response){
            alert(response)
            //$("#profile2")[0].reset()
          }
           })
        })
      
        }
        deleteUsers()
        // delete Categories
         function deleteCategory(){
          var deleteusers = $(".deletecategory")
          deleteusers.click(function(){
          var id = $(this).val()
          var formdata = new FormData()
          formdata.append("id",id)
          $.ajax({
          url:"php/delete_category.php",
          type: "post",
          data:formdata,
          contentType:false,
          processData: false,
          success: function(response){
            alert(response)
            //$("#profile2")[0].reset()
          }
           })
        })
      
        }
        deleteCategory()

        function deleteReports(){
          $(".deletereports").click(function(){
            var id = $(this).val()
            var formdata = new FormData()
            formdata.append("id",id)
            $.ajax({
            url:"php/delete_reports.php",
            type: "post",
            data:formdata,
            contentType:false,
            processData: false,
            success: function(response){
              alert(response)
              //$("#profile2")[0].reset()
            }
             })
          })
        }

        function deleteNovels(){
          $(".deletenovels").click(function(){
            var id = $(this).val()
            var formdata = new FormData()
            formdata.append("id",id)
            $.ajax({
            url:"php/delete_novel.php",
            type: "post",
            data:formdata,
            contentType:false,
            processData: false,
            success: function(response){
              alert(response)
              //$("#profile2")[0].reset()
            }
             })
          })
        }

       deleteNovels()

       function deleteAdmin(){
          $(".deleteadmins").click(function(){
            var id = $(this).val()
            var formdata = new FormData()
            formdata.append("id",id)
            $.ajax({
            url:"php/delete_admin.php",
            type: "post",
            data:formdata,
            contentType:false,
            processData: false,
            success: function(response){
              alert(response)
              //$("#profile2")[0].reset()
            }
             })
          })
        }

        deleteAdmin()
        //delete slider
         function deleteSlider(){
          $(".deleteslider").click(function(){
            var id = $(this).val()
            var formdata = new FormData()
            formdata.append("id",id)
            $.ajax({
            url:"php/delete_slider.php",
            type: "post",
            data:formdata,
            contentType:false,
            processData: false,
            success: function(response){
              alert(response)
              //$("#profile2")[0].reset()
            }
             })
          })
        }
        deleteSlider()


        //forms authentication


        //add new admin
        function addAdmin(){
          var addAdminBtn = $("#addAdminBtn")
        //authentication and validation
        addAdminBtn.click(()=>{
          var fullName = $("#fullName")
          var email = $("#email")
          var phone = $("#phone")
          var password = $("#password") 
          if (fullName.val()==="") {
          fullName.addClass('border-danger')
        }else{
          fullName.removeClass('border-danger')
        }

        if (email.val()==="") {
          email.addClass('border-danger')
        }else{
          email.removeClass('border-danger')
        }

        if (phone.val()==="") {
          phone.addClass('border-danger')
        }else{
          phone.removeClass('border-danger')
        }

        if (password.val()==="") {
          password.addClass('border-danger')
        }else{
          password.removeClass('border-danger')
        }
        if (fullName.val()  !="" && email.val() !="" && phone.val() !="" && password.val() !="") {
          console.log("true")
         var formdata = new FormData()
         formdata.append("fullName",fullName.val())
         formdata.append("email",email.val())
         formdata.append("phone",phone.val())
         formdata.append("password",password.val())
         $.ajax({
            url:"php/add_admin.php",
            type: "post",
            data:formdata,
            contentType:false,
            processData: false,
            success: function(response){
              alert(response)
              //$("#addAdminForm")[0].reset()
            }
         })
        }else{
          console.log("true")
        }

        })
        }

        addAdmin()

        //add new novel
        function addNovel(){
          var title = $("#title")
          var image = $("#image")
          var body = $("#body")
          var addNovelBtn = $("#addNovelBtn")
          var categoryTwo = $("#categoryTwo")
        //authentication and validation
        addNovelBtn.click(()=>{
          if (title.val()==="") {
          title.addClass('border-danger')
        }else{
          title.removeClass('border-danger')
        }

        if (image.val()==="") {
          image.addClass('border-danger')
        }else{
          image.removeClass('border-danger')
        }

        if (body.val()==="") {
          body.addClass('border-danger')
        }else{
          body.removeClass('border-danger')
        }
        if (categoryTwo.val()==="") {
          categoryTwo.addClass('border-danger')
        }else{
          categoryTwo.removeClass('border-danger')
        }
        
       
        if (title.val()  !="" && body.val() !="" && image.val() !="" && categoryTwo.val() !="") {
          //console.log("true")
         var formdata = new FormData()
         formdata.append("title",title.val())
         image = image[0].files
         formdata.append('image',image[0])
         formdata.append("body",body.val())
         formdata.append("categoryTwo",categoryTwo.val())
         $.ajax({
            url:"php/add_novel.php",
            type: "post",
            data:formdata,
            contentType:false,
            processData: false,
            success: function(response){
              alert(response)
              $("#addNovelForm")[0].reset()
            }
         })
        }else{
          console.log("true")
        }

        })
        }
        addNovel()

        
       

        //add new slider
        var addSliderBtn = $("#addSliderBtn")

        addSliderBtn.click(()=>{
          var sliderTitle = $("#sliderTitle")
          var sliderBody = $("#sliderBody")
          var sliderImage = $("#sliderImage")
          if (sliderTitle.val()==="") {
          sliderTitle.addClass('border-danger')
        }else{
          sliderTitle.removeClass('border-danger')
        }

        if (sliderBody.val()==="") {
          sliderBody.addClass('border-danger')
        }else{
          sliderBody.removeClass('border-danger')
        }

        if (sliderImage.val()==="") {
          sliderImage.addClass('border-danger')
        }else{
          sliderImage.removeClass('border-danger')
        }
        if (sliderTitle.val()  !="" && sliderBody.val() !="" && sliderImage.val() !="" ) {
          //console.log("true")
         var formdata = new FormData()
         formdata.append("title",sliderTitle.val())
         image = sliderImage[0].files
         formdata.append('image',image[0])
         formdata.append("body",sliderBody.val())
         $.ajax({
            url:"php/add_slider.php",
            type: "post",
            data:formdata,
            contentType:false,
            processData: false,
            success: function(response){
              alert(response)
              $("#editSliderForm")[0].reset()
            }
         })
        }else{
          console.log("true")
        }

      })

// edit profile 
    
          $("#editProfileBtn").click(()=>{
            var all_data = new FormData()
            var fullName = $("#full_name").val()
            var profileImage = $("#profile_image")[0].files[0]
            all_data.append("fullName",fullName)
            all_data.append("profileImage",profileImage)
            $.ajax({
              type: 'POST',
              enctype: 'multipart/form-data',
              cache:false,
              url: 'php/edit_profile.php',
              contentType:false,
              processData: false,
              data:all_data,
              success: function(data){
                alert(data)
              }
            })
          })

// display_real notifications
setInterval(()=>{
  $.ajax({
  url: 'php/notification_counter.php',
  type: 'post',
  contentType: false,
  processData: false,
  success: (counter)=>{
    $("#showCounter").text(counter)
    //alert(counter)

  }
}) 
 $.ajax({
  url: 'php/new_notification.php',
  type: 'post',
  contentType: false,
  processData: false,
  success: (content)=>{
    $("#newNotification").html(content)
    //alert(counter)

  }
})                   
},1000)
        

       
        
    })