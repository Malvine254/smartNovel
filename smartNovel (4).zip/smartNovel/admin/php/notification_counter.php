<?php 
require '../../php/config.php';
$select = $conn->query("SELECT * FROM draft WHERE new='0'");
echo $select->num_rows;


 ?>