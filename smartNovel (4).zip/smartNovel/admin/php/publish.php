<?php 
if (isset($_POST['finalBody'])) {
	date_default_timezone_set('Africa/Nairobi');
	include '../../php/config.php';
	$finalBody = mysqli_real_escape_string($conn,$_POST['finalBody']);
	$finalEmail = mysqli_real_escape_string($conn,$_POST['finalEmail']);
	$finalTitle = mysqli_real_escape_string($conn,$_POST['finalTitle']);
	$title = strtolower($finalTitle);
	$finalDate = mysqli_real_escape_string($conn,$_POST['finalDate']);
	$finalCategory = mysqli_real_escape_string($conn,$_POST['finalCategory']);
	$finalImage = mysqli_real_escape_string($conn,$_POST['finalImage']);
	$time_stamp = time();
	$id = rand(6000,5000000);
	$select = $conn->query("SELECT * FROM users WHERE email = '$finalEmail'");
	if ($select->num_rows>0) {
		while ($row=$select->fetch_assoc()) {
			$author = $row['fname']." ". $row['lname'];
			$profile = $row['profile'];
			$insert = $conn->query("INSERT INTO articles(title,body,`date`,category,author,profile,time_stamp,email,id_auto,image) VALUES('$finalTitle','$finalBody','$finalDate','$finalCategory','$author','$profile','$time_stamp','$finalEmail','$id','$finalImage')");
			if ($insert) {
				
				$update = $conn->query("UPDATE draft SET new = '1' WHERE email='$finalEmail' AND LOWER(title)='$title'");
				if ($update) {
					echo "Successfully Published";
				}
			}else{
				echo "failed";
			}
		}
	}else{
		echo "failed";
	}
	
}





 ?>