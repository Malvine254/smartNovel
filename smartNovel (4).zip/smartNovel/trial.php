<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- PDF library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.9.359/pdf.min.js"></script>

<!-- Text-to-speech library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/speak-tts/0.3.0/speak-tts.min.js"></script>
 <script src="assets/jquery/jquery.min.js"></script>

  <title></title>
</head>
<body>
  <form>
  <input type="file" onchange="convertPdfToMp3(this.files[0])">
</form>
<script>
  $('input[type="file"]').change(function () {
    convertPdfToMp3(this.files[0]);
  });
</script>

  <script>
    function convertPdfToMp3(file) {
  // Create a new PDF.js document object
  const pdfDoc = new pdfjsLib.getDocument(file);

  // Wait for the PDF document to load
  pdfDoc.promise.then((doc) => {
    let textContent = '';

    // Iterate through each page of the PDF and extract the text content
    for (let i = 1; i <= doc.numPages; i++) {
      doc.getPage(i).then((page) => {
        page.getTextContent().then((content) => {
          textContent += content.items.map((item) => item.str).join(' ');
        });
      });
    }

    // Wait for all pages to be processed
    setTimeout(() => {
      // Use the Speak TTS library to convert the text content to speech and save it as an MP3 file
      const speak = new SpeakTts();
      speak.init({
        volume: 1,
        lang: 'en-US',
        pitch: 1,
        rate: 1,
        voice: 'Google UK English Male',
        splitSentences: true,
        listeners: {
          onready: () => {
            speak.speak({
              text: textContent,
              listeners: {
                onend: () => {
                  speak.synth.cancel();
                  const audioBlob = speak.synth.getAudioData();
                  const audioUrl = URL.createObjectURL(audioBlob);
                  const audioDownloadLink = document.createElement('a');
                  audioDownloadLink.href = audioUrl;
                  audioDownloadLink.download = 'output.mp3';
                  audioDownloadLink.click();
                },
              },
            });
          },
        },
      });
    }, 5000); // Wait for 5 seconds to allow time for PDF to load
  });
}

  </script>

</body>
</html>