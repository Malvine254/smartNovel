<?php 
include 'php/config.php';
$numbering = 1;
$query = $conn->query("SELECT * FROM slider");
while ($row=$query->fetch_assoc()) {
	echo "  <div class='swiper-slide'>
                  <a href='single-post.html' class='img-bg d-flex align-items-end' style=\"background-image: url('".$row['image']."');\">
                    <div class='img-bg-inner'>
                      <h2>".$row['title']."</h2>
                      <p>".$row['body']."</p>
                    </div>
                  </a>
                </div>


	";

}
 ?>