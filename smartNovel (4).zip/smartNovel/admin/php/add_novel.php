<?php 
require '../../php/config.php';
date_default_timezone_set('Africa/Nairobi');
session_start();
$title = mysqli_real_escape_string($conn,$_POST['title']);
$image = mysqli_real_escape_string($conn,$_FILES['image']['name']);
$body = mysqli_real_escape_string($conn,$_POST['body']);
$categoryTwo = mysqli_real_escape_string($conn,$_POST['categoryTwo']);
$date = date('d-m-y');
$time = time();
$target = "../../assets/img/articles/".basename($image);
$path =  "assets/img/articles/".basename($image);
$email = $_SESSION['admin_email'];
$select = $conn->query("SELECT * FROM admin WHERE email='$email'");
while ($row=$select->fetch_assoc()) {
	$author = $row['name'];
	$profile = $row['profile'];
	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
	$insert = $conn->query("INSERT INTO articles (title,body,image,`date`,author,profile,time_stamp,category) VALUES('$title','$body','$path','$date','$author','$profile','$time','$categoryTwo')");
	if ($insert) {
		echo "Novel Added Successfully";
	}else{
		echo "failed";
	}
}else{
	echo "failed to move";
}

}

	



 ?>