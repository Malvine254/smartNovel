// Get the modal
var modal = $("#myModal");

// Get the button that opens the modal
var btn = $("#myBtn");

// Get the <span> element that closes the modal
var span = $(".close")[0];

// When the user clicks the button, open the modal 
function checkTimeout(){
  var timeout =  setTimeout(function() {
  modal.css({"display":"block"})
},1000)
  return timeout;

}


// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.css({"display":"none"})
  let fd = new FormData()
  fd.append("span",span);
  $.ajax({
     url: 'php/check_status.php', 
     type: 'post',
     data: fd,
    contentType: false,
    processData: false,
    success: (data)=>{
      //alert(data)

    }
      
  })
}

// When the user clicks anywhere outside of the modal, close it
function closedByClickingOutside(){
  window.onclick = function(event) {
  if (event.target == modal) {
   return modal.css({"display":"none"})
  }
}
}
closedByClickingOutside()
function checkNovelStatus(){
  $.ajax({
    url: 'php/check_status.php',
    type: 'post',
    success: (data)=>{
      if (data==="0"){
        //alert(data)
        checkTimeout()
        displayContent()
        closedByClickingOutside()
      }else{
        modal.css({"display":"none"})
      }

    }
  })

}

setInterval(()=>{
  checkNovelStatus()
},2000)
// realoda div
function displayContent(){
  setTimeout(()=>{
  var modelContent = $("#modelContent")
  return modelContent.load("php/new_notification.php")
},1000)
}
$("#dismis").click(()=>{
   modal.css({"display":"none"})
  let fd = new FormData()
  fd.append("span",span);
  $.ajax({
     url: 'php/check_status.php',
     type: 'post',
     data: fd,
    contentType: false,
    processData: false,
    success: (data)=>{

    }
      
  })
})
