<?php 


$arrayName = [
    		[10.3,'Jan','red'],
            [15.2,'Feb','blue'],
            [13.1,'Mar','orange'],
            [16.3,'Apr','maroon'],
            [12.5,'May','green'],
            [14.5,'Jun','orange'],
            [8.5,'Jul','black'],
            [6.5,'Aug','purple']
];
print_r(json_encode( $arrayName));




 ?>