<?php require 'php/check_session.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>forms</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS Files -->
  <link href="../assets/css/variables.css" rel="stylesheet">
  <link href="../assets/css/main.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="../fontAwesome/all.min.css">
  <link rel="stylesheet" type="text/css" href="../fontAwesome/fontawesome.min.css">

  <!-- =======================================================
  * Template Name: ZenBlog - v1.3.0
  * Template URL: https://bootstrapmade.com/zenblog-bootstrap-blog-template/
  * Author: BootstrapMade.com
  * License: https:///bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1>Admin</h1>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index">DASHBOARD</a></li>
          <li><a href="tables">TABLES</a></li>
          <li><a href="forms">FORMS</a></li>
          <li><a href="reports">REPORTS</a></li>
           <li class="dropdown"><a href="editorial"><span>EDITORIAL</span> <span class="text-danger">[<span id="showCounter">0</span>]</span><i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
                <span id="newNotification"></span>
            </ul>
          </li>
          <li><a href="php/logout">LOGOUT</a></li>
        </ul>
      </nav><!-- .navbar -->

      <div class="position-relative">
        <a href="#" class="mx-2"><span class="bi-facebook"></span></a>
        <a href="#" class="mx-2"><span class="bi-twitter"></span></a>
        <a href="#" class="mx-2"><span class="bi-instagram"></span></a>

        <a  href="#" class="mx-2 js-search-open"  id="searchButton"><span  class="bi-search"></span></a>
        <i  class="bi bi-list mobile-nav-toggle"></i>
        <a href="#" class="mx-2"><?php include 'php/display_image.php'; ?></a>

        <!-- ======= Search Form ======= -->
        <div class="search-form-wrap js-search-form-wrap">
          <form action="search-result.html" class="search-form">
            <span class="icon bi-search"></span>
            <h1 id="textToSearch" style="display: none;">Please, enter text to search.</h1>
            <input id="searchMe" type="text" placeholder="Search" class="form-control">
            <button  class="btn js-search-close"><span class="bi-x"></span></button>
          </form>
        </div><!-- End Search Form -->

      </div>

    </div>

  </header><!-- End Header --> 
  <style type="text/css">
      a{
        text-transform: uppercase;
      }
  </style>
  <main id="main">
    <section>
      <div class="container" data-aos="fade-up">
        <div class="row">
        </div>
        <div class="container">
          <div class="row justify-content-center">
            <div class=" col-lg-10 col-xl-10 mx-auto">
                <div class="my-4">

                <ul class="nav nav-tabs mb-4" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link" id="addAdminTab" data-toggle="tab" role="tab" aria-controls="home" aria-selected="true">Add Admin</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " id="addNovelTab" data-toggle="tab" role="tab" aria-controls="profile" aria-selected="false">Add Novel</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="editProfileTab" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">Edit Profile</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="editSliderTab" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">Edit Slider</a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" id="editSliderCategory" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">Add Category</a>
                    </li>
                </ul>
                <!-- start of add admin -->
                <div id="addAdmin">
                    <div class="row mb-3">
                        <div class="col-md-8">
                            <h5 class="mb-0 ">Add Admin</h5>
                  
                        </div>
                        
                    </div>
                    <div class="list-group mb-5 shadow">
                         <form  id="addAdminForm" method="POST"> 
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col">
                                    <strong class="mb-2">Add Admin</strong>
                                    <div class="row">
                                        
                                        <div class="col-md-6">
                                             <input id="fullName" type="text" class="form-control " placeholder="Admin Full Name">
                                        </div><br><br>
                                         <div class="col-md-6">
                                             <input id="email" type="text" class="form-control " placeholder="Admin Email Address">
                                        </div>
                                         
                                       
                                    </div><br>
                                    <div class="row">
                                      <div class="col-md-6">
                                             <input id="phone" type="text" class="form-control " placeholder="Phone Number">
                                        </div><br><br>
                                        <div class="col-md-6">
                                             <input id="password" type="text" class="form-control " placeholder="Password">
                                        </div>
                                    </div>
                                    </div>
                                   
                                </div><br>
                               <center><input type="button" class="btn btn-primary btn-sm" id="addAdminBtn" value="Add Admin"></center><br>
                            </div>
                            </form>
                        </div>
                        
                    </div>
                </div>
                <!-- end of add admin -->

                 <!-- start of add novel  -->
                 <div style="display: none;" id="addNovel">
                    <div class="row mb-3">
                        <div class="col-md-8">
                            <h5 class="mb-0 ">Add Novel</h5>
                  
                        </div>
                        
                    </div>
                    <div class="list-group mb-5 shadow">
                         <form  id="addNovelForm"> 
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col">
                                    <strong class="mb-2">Add Novel</strong>
                                    <div class="row">
                                        <div class="col-md-6">
                                             <input id="title" type="text" class="form-control " placeholder="Novel Title">
                                        </div><br><br>
                                         <div class="col-md-6">
                                           <input id="image" type="file" class="form-control " placeholder="Admin One time Password">
                                            
                                        </div>
                                         
                                       
                                    </div><br>
                                    <div class="row">
                                     <div class="col-md-4">
                                        <select style="height:60px;" id="categoryTwo" type="text" class="form-control ">
                                            <option selected disabled>Select Category</option>
                                           <?php include 'php/display_category.php'; ?>
                                        </select> 
                                     </div><br><br><br>
                                      <div class="col-md-8">
                                            <textarea id="body" type="text" class="form-control "  placeholder="Novel body..."></textarea> 
                                        </div>

                                        
                                    </div>
                                    </div>
                                   
                                </div><br>
                               <center><input type="button" class="btn btn-primary btn-sm" id="addNovelBtn" value="Add Novel"></center><br>
                            </div>
                            </form>
                        </div>
                        
                    </div>
               
               <!-- End of add novel -->

               <div style="display: none;" id="editSlider">
                    <div class="row mb-3">
                        <div class="col-md-8">
                            <h5 class="mb-0 ">Edit Slider</h5>
                  
                        </div>
                        
                    </div>
                    <div class="list-group mb-5 shadow">
                         <form  id="editSliderForm"> 
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col">
                                    <strong class="mb-2">Edit Slider</strong>
                                    <div class="row">
                                        
                                        <div class="col-md-6">
                                             <input id="sliderTitle" type="text" class="form-control " placeholder="Slider Title">
                                        </div><br><br>
                                         <div class="col-md-6">
                                           <input id="sliderImage" type="file" class="form-control " placeholder="Admin One time Password">
                                            
                                        </div>
                                         
                                       
                                    </div><br>
                                    <div class="row">
                                      <div class="col-md-12">
                                            <textarea id="sliderBody" type="text" class="form-control "  placeholder="Novel body..."></textarea> 
                                        </div>
                                        
                                    </div>
                                    </div>
                                   
                                </div><br>
                               <center><input type="button" class="btn btn-primary btn-sm" id="addSliderBtn" value="Add New Slider"></center><br>
                            </div>
                            </form>
                        </div>
                        
                    </div>
               
               <!-- End of edit slider -->

               <!-- start of edit profile  -->
                 <div style="display: none;" id="editProfile">
                    <div class="row mb-3">
                        <div class="col-md-8">
                            <h5 class="mb-0 ">Edit Profile</h5>
                  
                        </div>
                        
                    </div>
                    <div class="list-group mb-5 shadow">
                         <form  id="editProfileForm" method="POST"> 
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col">
                                    <strong class="mb-2">Edit Profile</strong>
                                    <div class="row">
                                        
                                        <div class="col-md-6">
                                             <input id="full_name" type="text" class="form-control " placeholder="Full Name">
                                        </div><br><br>
                                         <div class="col-md-6">
                                           <input id="profile_image" type="file" class="form-control " placeholder="Admin One time Password">
                                            
                                        </div>
                                         
                                       
                                    </div><br>
                                    </div>
                                   
                                </div><br>
                               <center><input type="button" class="btn btn-primary btn-sm" id="editProfileBtn" value="Edit Profile"></center><br>
                            </div>
                            </form>
                        </div>
                        
                    </div>
                     <!-- add category profile  -->
                 <div style="display: none;" id="hideAddCategory">
                    <div class="row mb-3">
                        <div class="col-md-8">
                            <h5 class="mb-0 ">Add Category</h5>
                  
                        </div>
                        
                    </div>
                    <div class="list-group mb-5 shadow">
                         <form  id="addCategory" method="POST"> 
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col">
                                    <p class="mb-2 text-center"><strong>Add Category</strong></p>
                                    <div class="row">
                                         <center>
                                        <div class="col-md-6">
                                           
                                                 <input id="categoryName" type="text" class="form-control " placeholder="Category Name">
                                           
                                        </div>
                                         </center>
                                        
                                         
                                       
                                    </div><br>
                                    </div>
                                   
                                </div><br>
                               <center><input type="button" class="btn btn-primary btn-sm" id="addCategoryBtn" value="Edit Profile"></center><br>
                            </div>
                            </form>
                        </div>
                        
                    </div>
                

  <!-- ======= Footer ======= -->
  

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>
  <script src="../assets/jquery/jquery.min.js"></script>
  <script src="js/tables05.js"></script>
  <script>
    $(document).ready(()=>{
        
      var addAdminTab = $("#addAdminTab")
      var addNovelTab = $("#addNovelTab")
      var editProfileTab = $("#editProfileTab")
      var editSliderTab = $("#editSliderTab")
      var editSliderCategory = $("#editSliderCategory")
      var addAdmin = $("#addAdmin")
      var addNovel = $("#addNovel")
      var editSlider = $("#editSlider")
      var editProfile = $("#editProfile")
      var addCategory = $("#hideAddCategory")
        addAdminTab.addClass("active")
        addAdminTab.click(()=>{
        addAdmin.css({"display":"block"})
        addNovel.css({"display":"none"})
        editProfile.css({"display":"none"})
        editSlider.css({"display":"none"})
        addCategory.css({"display":"none"})

        addAdminTab.addClass("active")
        addNovelTab.removeClass("active")
        editProfileTab.removeClass("active")
        addCategory.removeClass("active")
        editSliderCategory.removeClass("active")
      })
      addNovelTab.click(()=>{
        addAdmin.css({"display":"none"})
        addNovel.css({"display":"block"})
        editProfile.css({"display":"none"})
        editSlider.css({"display":"none"})
        addCategory.css({"display":"none"})

        addAdminTab.removeClass("active")
        addNovelTab.addClass("active")
        editProfileTab.removeClass("active")
        editSliderTab.removeClass("active")
        editSliderCategory.removeClass("active")

      })
      editProfileTab.click(()=>{
        addAdmin.css({"display":"none"})
        addNovel.css({"display":"none"})
        editProfile.css({"display":"block"})
        editSlider.css({"display":"none"})
        addCategory.css({"display":"none"})

        addAdminTab.removeClass("active")
        addNovelTab.removeClass("active")
        editProfileTab.addClass("active")
        editSliderTab.removeClass("active")
        editSliderCategory.removeClass("active")

      })
      editSliderTab.click(()=>{
        addAdmin.css({"display":"none"})
        addNovel.css({"display":"none"})
        editProfile.css({"display":"none"})
        editSlider.css({"display":"block"})
        addCategory.css({"display":"none"})

        addAdminTab.removeClass("active")
        addNovelTab.removeClass("active")
        editProfileTab.removeClass("active")
        editSliderTab.addClass("active")
        editSliderCategory.removeClass("active")


      })

      editSliderCategory.click(()=>{
        addAdmin.css({"display":"none"})
        addNovel.css({"display":"none"})
        editProfile.css({"display":"none"})
        addCategory.css({"display":"block"})
        editSlider.css({"display":"none"})

        editSliderCategory.addClass("active")
        addAdminTab.removeClass("active")
        addNovelTab.removeClass("active")
        editProfileTab.removeClass("active")
        editSliderTab.removeClass("active")

      })

      // add to category

      var categoryName = $("#categoryName")
      var addCategoryBtn = $("#addCategoryBtn")
      addCategoryBtn.click(()=>{
        var form = new FormData()
        form.append("category",categoryName.val())
        $.ajax({
            url: "php/add_category.php",
            type: "post",
            contentType: false,
            processData: false,
            data: form,
            success: (e)=>{
                alert(e)
            }
        })
      })



    })
    
    
  </script>

</body>

</html>