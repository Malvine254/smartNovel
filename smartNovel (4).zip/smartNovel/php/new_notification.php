<?php 
session_start();
require 'config.php';
$email = mysqli_real_escape_string($conn,$_SESSION['email']);
$select = $conn->query("SELECT * FROM articles WHERE email = '$email' AND status='0' LIMIT 1");
if ($select->num_rows>0) {
	while ($row=$select->fetch_assoc()) {
		echo "<h3 class=\"text-center\"><u>".$row['title']."</u> approved</h3></blockquote>
    <p class=\"text-center\">Congratulations <strong>".$row['author']."</strong>, your novel has been approved by the editorial department after undergoing thorough review and editing. Click <a href='single-post?id=".$row['id_auto']."' class='text-info' id='dismis'>here</a> to view</p>";
	}
}else{
	echo "<li><a >No category was found!!</a></li>";
}


 ?>