<?php require 'php/check_session.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>create</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="fontAwesome/all.min.css">
  <link rel="stylesheet" type="text/css" href="fontAwesome/fontawesome.min.css">
  <link rel="stylesheet" type="text/css" href="modal/modal1.css">

  <!-- Template Main CSS Files -->
  <link href="assets/css/variables.css" rel="stylesheet">
  <link href="assets/css/main.css" rel="stylesheet">
  <script src="ckeditor/ckeditor.js"></script>

  <!-- =======================================================
  * Template Name: ZenBlog - v1.3.0
  * Template URL: https://bootstrapmade.com/zenblog-bootstrap-blog-template/
  * Author: BootstrapMade.com
  * License: https:///bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
  <div id="loading">
    <img width="45px" height="45px" id="loader-image" src="loader/loader.gif">
  </div>

  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1>SmartNovel</h1>
      </a>

     <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index">HOME</a></li>
          <li class="dropdown"><a href="category"><span>CATEGORIES</span><i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
             <?php include 'php/display_category.php'; ?>
            </ul>
          </li>
          <li class='active'><a href="create"><u>CREATE NOVEL</u></a></li>
          <li><a href="settings">SETTINGS</a></li>
           <li><a id="logOut">LOGOUT</a></li>
        </ul>
      </nav><!-- .navbar -->

      <div class="position-relative">
        <a href="#" class="mx-2"><span class="bi-facebook"></span></a>
        <a href="#" class="mx-2"><span class="bi-twitter"></span></a>
        <a href="#" class="mx-2"><span class="bi-instagram"></span></a>

        <a  href="#" class="mx-2 js-search-open"  id="searchButton"><span  class="bi-search"></span></a>
        <i  class="bi bi-list mobile-nav-toggle"></i>

        <!-- ======= Search Form ======= -->
        <div class="search-form-wrap js-search-form-wrap">
          <form action="search-result.html" class="search-form">
            <span class="icon bi-search"></span>
            <h1 id="textToSearch" style="display: none;">Please, enter text to search.</h1>
            <input id="searchMe" type="text" placeholder="Search" class="form-control">
            <button  class="btn js-search-close"><span class="bi-x"></span></button>
          </form>
        </div><!-- End Search Form -->

      </div>

    </div>

  </header><!-- End Header -->

<main id="main">
    <section>
      <div class="container" data-aos="fade-up">
       <!--  <div class="row">
          <div class="col-lg-12 text-center mb-5">
            <h3 class="">Create New Novel</h3>
          </div>
        </div> -->
        <div class="container">
          <div class="row justify-content-center">
            <div class=" col-lg-10 col-xl-10 mx-auto">
                <div class="my-4">
                <ul class="nav nav-tabs mb-4" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="titleTab" data-toggle="tab" role="tab" aria-controls="home" aria-selected="true">ADD TITLE</a>
                    </li>
                    <li class="nav-item" >
                        <a class="nav-link " id="imageTab" data-toggle="tab" role="tab" aria-controls="profile" aria-selected="false">ADD IMAGE</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="categoryTab" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">ADD CATEGORY</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"  id="bodyTab" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">ADD BODY</a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link"  id="previewTab" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">NOVEL PREVIEW</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"  id="restartTab" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">RESTART</a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link text-danger"  id="discardTab" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">DISCARD ALL</a>
                    </li>
                </ul>
                <!-- start of add title -->
                <div id="addTitle">
                    <div class="row mb-3">
                      <!-- <h5 class="mb-0 ">Add Title</h5> -->
                          <form enctype="multipart/form-data" method="POST" >
                           <div class="row">
                             <div class="col-md-6">
                              <label>Add Title</label>
                                <textarea class="form-control" id="title" type="text"  name="profile" placeholder="Add Title"></textarea>
                             </div>
                             <div  class="col-md-6 mt-2">
                               <label></label><br>
                                <button type="button" style="height: 50px;" class="btn btn-primary" id="nextButton" type="text" >GO TO NEXT</button>
                             </div>
                           </div>
                          </form>
                    </div>
                   
                </div>
                <!-- end of add title -->
                <!-- start of add image -->
                <div id="addImage" style="display: none;">
                    <div class="row mb-3">
                      <!-- <h5 class="mb-0 ">Add Title</h5> -->
                          <form enctype="multipart/form-data" method="POST" >
                           <div class="row">
                             <div class="col-md-6">
                              <label>Add Image</label>
                                <input style="height: 60px;" class="form-control" id="myImage" type="file"  name="profile" placeholder="Add Image">
                             </div>
                             <div  class="col-md-6 mt-2">
                               <label></label><br>
                                <button type="button" style="height: 50px;" class="btn btn-primary" id="nextButton1" type="text" >GO TO NEXT</button>
                             </div>
                           </div>
                          </form>
                    </div>
                   
                </div>
                <!-- end of add image -->
                <!-- start of add Category -->
                <div id="addCategory" style="display: none;">
                    <div class="row mb-3">
                      <!-- <h5 class="mb-0 ">Add Title</h5> -->
                          <form enctype="multipart/form-data" method="POST" >
                           <div class="row">
                             <div class="col-md-6">
                              <label>Add Category</label>
                                <select id="category" style="height: 60px;" class="form-control" id="" type="text"  name="profile">
                                  <!-- <option selected disabled>Add Category</option> -->
                                 <?php 
                                  require 'php/config.php';
                                  $select = $conn->query("SELECT * FROM categories");
                                  if ($select->num_rows>0) {
                                    while ($row=$select->fetch_assoc()) {
                                      echo "<option value='".$row['category']."'>".$row['category']."</option>";
                                    }
                                  }else{
                                    echo "<option disabled>No category found</option>";
                                  } ?>
                                </select>
                             </div>
                             <div  class="col-md-6 mt-2">
                               <label></label><br>
                                <button type="button" style="height: 50px;" class="btn btn-primary d" id="nextButton2" type="text" >GO TO NEXT</button>
                             </div>
                           </div>
                          </form>
                    </div>
                   
                </div>
                <!-- end of add Category -->

                <!-- start of addBody -->
                <div id="addBody" style="display: none;">
                    <div class="row mb-3 shadow">
                      <!-- <h5 class="mb-0 ">Add Title</h5> -->
                      <div class="justify-content-center mb-3 mt-2">
                        <center>
                          <button type="button" id="start" class="fa fa-play btn btn-info text-light"> Start Assistance</button>
                          <button type="button" id="stop" class="fa fa-stop btn btn-danger" > Stop Assistance</button>
                          <button type="button" id="pause" class="fa fa-pause btn btn-primary"> Pause Assistance</button>
                          <span id="status"></span>
                        </center>
                      </div>
                      <form enctype="multipart/form-data" method="POST" >
                       <textarea style="font-size: 24px;" rows="10" id="body" class="form-control border-light" placeholder="type here..." ></textarea>
                       <div class="mt-3 mb-3 ">
                        <center>
                           <button id="nextButton3" type="button" class="btn btn-primary">Finish Creating Novel</button>
                        </center>
                       </div>
                      </form>
                    </div>
                </div>
                <br><br>
                <!-- end of add body -->
                <!-- start of addBody -->
                <div id="addPreview" style="display: none;">
                    <div class="row mb-3 mt-3 shadow">
                      <!-- <h5 class="mb-0 ">Add Title</h5> -->
                      <div class=" mb-3">
                       
                        
                        
                       <div id="myDiv"></div>
                      
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    </div>
    </div>
    </section>
    <!-- Trigger/Open The Modal -->
    <!-- <button id="myBtn">Open Modal</button> -->

    <!-- The Modal -->
    <div id="myModal" class="modal">

      <!-- Modal content -->
      <div class="modal-content">
        <span class="close">&times;</span>
        <div id="modelContent">
         
        </div>
      </div>

    </div>

    

  <!-- End #main -->

  <!-- ======= Footer ======= -->
  
<!-- h1 id="intro" style="display: none;">Welcome to, create your own story page. Press one, to add title to your new book. Press two to add body to your new Book. Press 3 to exit text Box. Finally,press 4 to preview your story. </h1>
  <a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a> -->

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script src="assets/jquery/jquery.min.js"></script>
  <script src="assets/js/articulate.js"></script>
  <script src="assets/js/settings1.js"></script>
  <script src="assets/js/voiceRecognition04.js"></script>
  <script type="text/javascript" src="modal/modal.js"></script>
  <script>
  var SpeechRecogntion = window.speechRecognition || window.webkitSpeechRecognition;
  var recognition = new window.SpeechRecogntion(); 
  $(document).ready(()=>{
     if (window.loaded=true) {
         $("#loading").css("display","none");
      }

      function returnText(element){
        return element.val()

      }

      var start = $("#start")
      var stop = $("#stop")
      var body = $("#body")

      body.focus()
      var instration = $("#status")
      start.click(()=>{
       returnSpeechRecog(body,instration)
        
      })
       stop.click(()=>{
        recognition.stop()
        instration.text("Stopped")
      })
     

  })
  
 

    
  </script>

</body>

</html>