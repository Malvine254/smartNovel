  function returnBodyText(){
      return $("#body").val()
     }

  function returnSpeechRecog(textbox,instration){
       var content = returnBodyText();
        recognition.continuous = true

        recognition.onstart = function (){
            return instration.text('Voice Recognition Initiated')
        }

        recognition.onspeechend = function (){
           return instration.text('Timeout');
        }

        recognition.onerror = function (event){ 
            return instration.text('Connection lost');
            //return console.log(event);
        }

        recognition.onresult = function(event) {
            var current = event.resultIndex;
            var transcript = event.results[current][0].transcript;
            var confidence = event.results[current][0].confidence;
            console.log(transcript);
             content += transcript;
             return textbox.val(content);
        };
                      
            if(content.length){
                content += ''
            }
    
           return recognition.start()
      
    }

    function returnPreview(){
        var data = new FormData()
        var fileWithValue = $("#file").val()
        var file = $("#file")[0].files
        data.append('image',file[0])
        data.append("title",title.val())
        data.append("body",body.val())
        data.append("fileWithValue",fileWithValue)
        data.append("category",category.val())
        $.ajax({
        url : 'php/draft.php',
        type: 'post',
        data: data,
        processData: false,
        contentType: false,
        success: function(c){
           return previewBody.html(c)
        }
  })
    }

     // navigation tabs
  var titleTab = $("#titleTab")
  var imageTab = $("#imageTab")
  var bodyTab =  $("#bodyTab")
  var categoryTab = $("#categoryTab")
  var previewTab = $("#previewTab")
  var discardTab = $("#discardTab")
  // what to show when clicked
  var addCategory = $("#addCategory")
  var addTitle = $("#addTitle")
  var addImage = $("#addImage")
  var addBody = $("#addBody")
  var addPreview = $("#addPreview")
  // all next buttons initialization
  var nextButton = $("#nextButton")
  var nextButton1 = $("#nextButton1")
  var nextButton2 = $("#nextButton2")
  var nextButton3 = $("#nextButton3")
   // variables initialization
  var title = $("#title")
  var myImage = $("#myImage")
  var category = $("#category")
  var body = $("#body")

  // when next button is clicked
  nextButton.click(()=>{
    if (title.val()==="") {
        title.addClass("border-danger")
    }else{
        // ajax call
    let formdata = new FormData()
     formdata.append("button1",nextButton);
     $.ajax({
        url: 'php/next.php',
        type: 'post',
        contentType: false,
        processData: false,

        data: formdata,
        success: (data)=>{
            //console.log(data)
        }

     })
    // hide all other elements
    titleTab.removeClass("active")
    imageTab.addClass("active")
    bodyTab.removeClass("active")
    categoryTab.removeClass("active")
    previewTab.removeClass("active")

    addTitle.css({"display":"none"})
    addImage.css({"display":"block"})
    addCategory.css({"display":"none"})
    addBody.css({"display":"none"})
    addPreview.css({"display":"none"})

    }
    
  })

  // when nextbutton1 is clicked
  nextButton1.click(()=>{
     if (myImage.val()==="") {
        myImage.addClass("border-danger")
    }else{
        // ajax call
    let formdata = new FormData()
     formdata.append("button2",nextButton1);
     $.ajax({
        url: 'php/next.php',
        type: 'post',
        contentType: false,
        processData: false,

        data: formdata,
        success: (data)=>{
            //console.log(data)
        }
        })
    // hide all other elements
    titleTab.removeClass("active")
    imageTab.removeClass("active")
    bodyTab.removeClass("active")
    categoryTab.addClass("active")
    previewTab.removeClass("active")

    addTitle.css({"display":"none"})
    addImage.css({"display":"none"})
    addCategory.css({"display":"block"})
    addBody.css({"display":"none"})
    addPreview.css({"display":"none"})

    }
    
  }) 

  // when nextbutton2 is clicked
  nextButton2.click(()=>{
     if (category.val()==="") {
        category.addClass("border-danger")
    }else{
         // ajax call
    let formdata = new FormData()
     formdata.append("button3",nextButton2);
     $.ajax({
        url: 'php/next.php',
        type: 'post',
        contentType: false,
        processData: false,

        data: formdata,
        success: (data)=>{
            //console.log(data)
        }
        })
    // hide all other elements
    titleTab.removeClass("active")
    imageTab.removeClass("active")
    bodyTab.addClass("active")
    categoryTab.removeClass("active")
    previewTab.removeClass("active")

    addTitle.css({"display":"none"})
    addImage.css({"display":"none"})
    addCategory.css({"display":"none"})
    addBody.css({"display":"block"})
    addPreview.css({"display":"none"})

    }
   
  })
  nextButton3.click(()=>{
     if (body.val()==="") {
      alert("Body cannot be empty!!")
    }else{
        displayDrafts()
          recognition.stop()
        //returnSpeechRecog()
    // ajax call
    let formdata = new FormData()
     formdata.append("button4",nextButton3);
     $.ajax({
        url: 'php/next.php',
        type: 'post',
        contentType: false,
        processData: false,

        data: formdata,
        success: (data)=>{
            //console.log(data)
        }
        })
    // hide all other elements
    titleTab.removeClass("active")
    imageTab.removeClass("active")
    bodyTab.removeClass("active")
    categoryTab.removeClass("active")
    previewTab.addClass("active")

    addTitle.css({"display":"none"})
    addImage.css({"display":"none"})
    addCategory.css({"display":"none"})
    addBody.css({"display":"none"})
    addPreview.css({"display":"block"})

    }
    
  })

  // previewTab.click(()=>{
  //   // hide all other elements
  //   titleTab.removeClass("active")
  //   imageTab.removeClass("active")
  //   bodyTab.removeClass("active")
  //   categoryTab.removeClass("active")
  //   previewTab.addClass("active")

  //   addTitle.css({"display":"none"})
  //   addImage.css({"display":"none"})
  //   addCategory.css({"display":"none"})
  //   addBody.css({"display":"none"})
  //   addPreview.css({"display":"block"})
  // })
  
  //return drafts contents
  function returnDraftsContents(i){
    message = ""
    $.ajax({
        url: 'php/return_book_desc.php',
        async: false,
        cache: false,
        type: 'post',
        success: (data)=>{
            if (data ===" ") {
               
            }else{
                let title = jQuery.parseJSON(data)
                message =  title[i]  
            }
           
        }
    })
    return message;
  }

 // variables initialization
  var title = $("#title")
  var myImage = $("#myImage")
  var category = $("#category")
  var body = $("#body")
 title.val(returnDraftsContents(1))
 body.val(returnDraftsContents(0))
 //myImage.val(returnDraftsContents(3))
 //alert(myImage.attr('value',returnDraftsContents(3)))
 category.val(returnDraftsContents(2)).change()
//save as draft
 function saveAsDraft(){
       var data = new FormData()
        var file = myImage[0].files
        data.append("title",title.val())
        data.append("body",$('#body').val())
        data. append("fileWithValue",myImage.val())
        data. append("image",file[0])
        data.append("category",category.val())
      $.ajax({
        url : 'php/drafts.php',
        type: 'post',
        data: data,
        processData: false,
        contentType: false,
        success: function(e){
          //alert(e)
        }
            })
     }
      //restart tab when pressed
     var restartTab = $("#restartTab")
     restartTab.css({"display":"none"})
     restartTab.click(()=>{
        // hide all other elements
        titleTab.addClass("active")
        imageTab.removeClass("active")
        bodyTab.removeClass("active")
        categoryTab.removeClass("active")
        previewTab.removeClass("active")

        addTitle.css({"display":"block"})
        addImage.css({"display":"none"})
        addCategory.css({"display":"none"})
        addBody.css({"display":"none"})
        addPreview.css({"display":"none"})
        restartTab.css({"display":"none"})
     })

     // save as drafts when finish creating button pressed
     nextButton3.click(()=>{
        saveAsDraft()
         restartTab.css({"display":"block"})
     })



     
  
// check when last edited
  function ResumptionStatus(){
     $.ajax({
        url: 'php/resume_back.php',
        type: 'post',
        success: (e)=>{
            if (e !="") {
                let data = jQuery.parseJSON(e)
            if (data[0]==='0') {
                return titleTab.removeClass("active"),
                imageTab.removeClass("active"),bodyTab.removeClass("active"),
                categoryTab.removeClass("active"),previewTab.removeClass("active"),
                titleTab.addClass("active")

            }else if (data[1]==='0'){
                 return nextButton.click()

            }else if (data[2]==='0'){
                 return nextButton1.click()
            }else if (data[3]==='0'){
                 return nextButton3.click()
            }else{
                 return nextButton3.click()
            }
            if (data[0]==='1' || data[1]==='1' || data[2]==='1') {
                promptUserExitig()
            }
            }
            
            
        }
        })

  }
    ResumptionStatus()
// discard novel
discardTab.click(()=>{
    var retVal = confirm("Are you sure you Want to discard this novel?")
      if (retVal==true) {
        let formdata = new FormData()
        formdata.append("discard",discardTab)
       $.ajax({
        url:"php/next.php",
        type:"post",
        data: formdata,
        contentType: false,
        processData: false,
        success: function(data){
          //alert(data)
          location.reload()

        }
       })
        return true
      }else{
        return false
      }
})
//notify users leaving the page before saving changes
function promptUserExitig(){
  $(window).on('beforeunload',(e)=>{
  if (e) {
    return e
  }else{

  }
 })
 }
 function displayDrafts(){
    setTimeout(()=>{
        $("#myDiv").load("php/drafts.php")
    },1000)
 }