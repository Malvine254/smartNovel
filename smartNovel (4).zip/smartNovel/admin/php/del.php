<?php 
 echo "<script>$(\".deletenovels\").click(()=>{
      var id =  $(this).val()
      var fd = new FormData()
      fd.append('id',id)
      $.ajax({
      	url: 'deletenovels.php',
      	type: 'post',
      	data:fd,
      	success: (data)=>{
      		alert(data)
      	}
      	})
    })</script>";





 ?>