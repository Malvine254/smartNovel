<?php require 'php/check_session.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>tables</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@400;500&family=Inter:wght@400;500&family=Playfair+Display:ital,wght@0,400;0,700;1,400;1,700&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">

  <!-- Template Main CSS Files -->
  <link href="../assets/css/variables.css" rel="stylesheet">
  <link href="../assets/css/main.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="../fontAwesome/all.min.css">
  <link rel="stylesheet" type="text/css" href="../fontAwesome/fontawesome.min.css">

  <!-- =======================================================
  * Template Name: ZenBlog - v1.3.0
  * Template URL: https://bootstrapmade.com/zenblog-bootstrap-blog-template/
  * Author: BootstrapMade.com
  * License: https:///bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header d-flex align-items-center fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <!-- <img src="assets/img/logo.png" alt=""> -->
        <h1>Admin</h1>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a href="index">DASHBOARD</a></li>
          <li><a href="tables">TABLES</a></li>
          <li><a href="forms">FORMS</a></li>
          <li><a href="reports">REPORTS</a></li>
          <li class="dropdown"><a href="editorial"><span>EDITORIAL</span> <span class="text-danger">[<span id="showCounter">0</span>]</span><i class="bi bi-chevron-down dropdown-indicator"></i></a>
            <ul>
                <span id="newNotification"></span>
            </ul>
          </li>
          <li><a href="php/logout">LOGOUT</a></li>
        </ul>
      </nav><!-- .navbar -->

      <div class="position-relative">
        <a href="#" class="mx-2"><span class="bi-facebook"></span></a>
        <a href="#" class="mx-2"><span class="bi-twitter"></span></a>
        <a href="#" class="mx-2"><span class="bi-instagram"></span></a>

        <a  href="#" class="mx-2 js-search-open"  id="searchButton"><span  class="bi-search"></span></a>
        <i  class="bi bi-list mobile-nav-toggle"></i>
        <a href="#" class="mx-2"><?php include 'php/display_image.php'; ?></a>

        <!-- ======= Search Form ======= -->
        <div class="search-form-wrap js-search-form-wrap">
          <form action="search-result.html" class="search-form">
            <span class="icon bi-search"></span>
            <h1 id="textToSearch" style="display: none;">Please, enter text to search.</h1>
            <input id="searchMe" type="text" placeholder="Search" class="form-control">
            <button  class="btn js-search-close"><span class="bi-x"></span></button>
          </form>
        </div><!-- End Search Form -->

      </div>

    </div>

  </header><!-- End Header -->
  <style type="text/css">
      a{
        text-transform: uppercase;
      }
  </style>
  <main id="main">
    <section>
      <div class="container" data-aos="fade-up">
        <div class="row">
        </div>
        <div class="container">
          <div class="row justify-content-center">
            <div class=" col-lg-10 col-xl-10 mx-auto">
                <div class="my-4">
                <ul class="nav nav-tabs mb-4" id="myTab" role="tablist">
                    <li class="nav-item">
                       <a class="nav-link active" id="usersTab" data-toggle="tab" role="tab" aria-controls="home" aria-selected="true">Users Table</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " id="adminTab" data-toggle="tab" role="tab" aria-controls="profile" aria-selected="false">Admins Table</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" id="novelsTab" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">Novels Table</a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" id="reportsTab" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">Slider Table</a>
                    </li>
                     <li class="nav-item">
                        <a class="nav-link" id="categoryTab" data-toggle="tab" role="tab" aria-controls="contact" aria-selected="false">Category Table</a>
                    </li>
                </ul>
                <!-- start of user table -->
                <div id="userTable">
                    <div class="row mb-3">
                        <div class="col-md-8">
                            <h5 class="mb-0 ">Users Table</h5>
                  
                        </div>
                        
                    </div>
                    <div class="list-group mb-5 shadow">
                         <form  id="formClear"> 
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col-md-12 table-responsive " style="height: 500px; overflow-y: scroll;">
                                    <strong class="mb-2">Users Table</strong>
                                    <table class="table table-bordered responsive">
                                      <tr>
                                         <th>#</th>
                                         <th>Full Name</th>
                                         <th>Email</th>
                                         <th>Disability</th>
                                         <th>Action</th>
                                      </tr>
                                     <?php include 'php/display_users_table.php'; ?>
                                    </table>
                                   
                                    
                                    </div>
                                   
                                </div><br>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
                <!-- end of user table -->

                  <!-- start of admin table -->
                <div style="display: none;" id="adminTable">
                    <div class="row mb-3">
                        <div class="col-md-8">
                            <h5 class="mb-0 ">Admins Table</h5>
                  
                        </div>
                        
                    </div>
                    <div class="list-group mb-5 shadow">
                         <form  id="formClear"> 
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col table-responsive" style="height: 500px; overflow-y: scroll;">
                                    <strong class="mb-2">Admins Table</strong>
                                    <table class="table table-bordered">
                                      <tr>
                                         <th>#</th>
                                         <th>Full Name</th>
                                         <th>Email</th>
                                         <th>Phone</th>
                                         <th>Action</th>
                                      </tr>
                                      <?php include 'php/display_admin_table.php'; ?>
                                    </table>
                                   
                                    
                                    </div>
                                   
                                </div><br>
                            </div>
                            </form>
                        </div>
                        
                    </div>
                <!-- end of  admin table -->

                 <!-- start of novel table -->
                <div style="display: none;" id="novelTable">
                    <div class="row mb-3">
                        <div class="col-md-8">
                            <h5 class="mb-0 ">Novel Table</h5>
                  
                        </div>
                        
                    </div>
                    <div class="list-group mb-5 shadow">
                         <form  id="formClear"> 
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col table-responsive" style="height: 500px; overflow-y: scroll;">
                                    <strong class="mb-2">Novel Table</strong>
                                    <table class="table table-bordered ">
                                      <tr>
                                         <th>#</th>
                                         <th>Title</th>
                                         <th>Body</th>
                                         <th>Date</th>
                                         <th>Image</th>
                                         <th>Category</th>
                                      </tr>
                                      <?php include 'php/display_novel_table.php'; ?>
                                    </table>
                              
                                    </div>
                                   
                                </div><br>
                            </div>
                            </form>
                        </div>
                        
                    </div>
               
                <!-- end of novel table -->
                 <!-- start of novel table -->
                <div style="display: none;" id="reportsTable">
                    <div class="list-group mb-5 shadow">
                         <form  id="formClear"> 
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col table-responsive" style="height: 500px; overflow-y: scroll;">
                                    <strong class="mb-2">Slider Table</strong>
                                    <table class="table table-bordered">
                                      <tr>
                                         <th>#</th>
                                         <th>Slider title</th>
                                         <th>Slider Body</th>
                                         <th>Slider Image</th>
                                         <th>Action</th>
                                      </tr>
                                      <?php include 'php/display_slider_table.php'; ?>
                                    </table>
                                   
                                    
                                    </div>
                                   
                                </div><br>
                            </div>
                            </form>
                        </div>
                        
                    </div>
                     <!-- start of category table -->
                <div style="display: none;" id="categoryTable">
                    <div class="list-group mb-5 shadow">
                         <form  id="formClear"> 
                        <div class="list-group-item">
                            <div class="row align-items-center">
                                <div class="col table-responsive" style="height: 500px; overflow-y: scroll;">
                                    <strong class="mb-2">Category Table</strong>
                                    <table class="table table-bordered" >
                                      <tr>
                                         <th>#</th>
                                         <th>Category Name</th>
                                         <th>Action</th>
                                      </tr>
                                      <?php include 'php/display_category_table.php'; ?>
                                    </table>
                                   
                                    
                                    </div>
                                   
                                </div><br>
                            </div>
                            </form>
                        </div>
                        
                    </div>
  <!-- ======= Footer ======= -->
  

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../assets/js/main.js"></script>
  <script src="../assets/jquery/jquery.min.js"></script>
  <script src="js/tables05.js"></script>
  <script>
          $(".vc").click((e)=>{
          var id = $(e.target)
          //console.log(id.val())
          $("#body"+id.val()).css({"display":"none"})
          //console.log()
          $("#"+id.val()).css({"display":"block"})
           id.css({"display":"none"})
          
          //console.log(original)
      })

    
     var usersTab = $("#usersTab")
      var adminTab = $("#adminTab")
      var novelsTab = $("#novelsTab")
      var reportsTab = $("#reportsTab")
      var categoryTab = $("#categoryTab")

      var userTable = $("#userTable")
      var adminTable = $("#adminTable")
      var novelTable = $("#novelTable")
      var reportsTable = $("#reportsTable")
      var categoryTable = $("#categoryTable")
      categoryTab.click(()=>{
        userTable.css({"display":"none"})
        adminTable.css({"display":"none"})
        novelTable.css({"display":"none"})
        reportsTable.css({"display":"none"})
        categoryTable.css({"display":"block"})

        usersTab.removeClass("active")
        adminTab.removeClass("active")
        novelsTab.removeClass("active")
        reportsTab.removeClass("active")
        categoryTab.addClass("active")
      })
      usersTab.click(()=>{
        userTable.css({"display":"block"})
        adminTable.css({"display":"none"})
        novelTable.css({"display":"none"})
        reportsTable.css({"display":"none"})
        categoryTable.css({"display":"none"})

        usersTab.addClass("active")
        adminTab.removeClass("active")
        novelsTab.removeClass("active")
        reportsTab.removeClass("active")
        categoryTab.removeClass("active")
      })
      adminTab.click(()=>{
        userTable.css({"display":"none"})
        adminTable.css({"display":"block"})
        novelTable.css({"display":"none"})
        reportsTable.css({"display":"none"})
        categoryTable.css({"display":"none"})


        usersTab.removeClass("active")
        adminTab.addClass("active")
        novelsTab.removeClass("active")
        reportsTab.removeClass("active")
        categoryTab.removeClass("active")
      })
      novelsTab.click(()=>{
        userTable.css({"display":"none"})
        adminTable.css({"display":"none"})
        novelTable.css({"display":"block"})
        reportsTable.css({"display":"none"})
        categoryTable.css({"display":"none"})

        usersTab.removeClass("active")
        adminTab.removeClass("active")
        novelsTab.addClass("active")
        reportsTab.removeClass("active")
        categoryTab.removeClass("active")
      })
      reportsTab.click(()=>{
        userTable.css({"display":"none"})
        adminTable.css({"display":"none"})
        novelTable.css({"display":"none"})
        reportsTable.css({"display":"block"})
        categoryTable.css({"display":"none"})

        usersTab.removeClass("active")
        adminTab.removeClass("active")
        novelsTab.removeClass("active")
        reportsTab.addClass("active")
        categoryTab.removeClass("active")
      })

   
    
    
  </script>

</body>

</html>