<?php 
include '../php/config.php';
$numbering = 1;
$query = $conn->query("SELECT * FROM admin");
while ($row=$query->fetch_assoc()) {
	echo " <tr>
            <td>".$numbering++."</td>
            <td>".$row['fname']." ".$row['lname']."</td>
            <td>".$row['email']."</td>
            <td>".$row['disable']."</td>
            <td><button type='button' class='deleteusers btn btn-light' value='".$row['id']."'><i class='fa fa-trash'></i></button></td>
          </tr>


	";



}
 ?>